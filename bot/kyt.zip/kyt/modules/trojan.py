from kyt import *
import subprocess, requests, re
from telethon import events, Button

# ===================== Helpers umum =====================
def _sh(cmd, default=""):
    try:
        return subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT)\
                        .decode("utf-8", "ignore").strip()
    except Exception:
        return default

def box(title, body_lines, footer=None):
    lines = ["╭────────────────────", f"│ {title}", "├────────────────────"]
    for ln in body_lines:
        for sub in ln.split("\n"):
            lines.append(f"│ {sub}")
    if footer:
        lines += ["├────────────────────", f"│ {footer}"]
    lines.append("╰────────────────────")
    return "\n".join(lines)

# ====== ANSI cleaner (untuk output Cek Config agar tidak berantakan) ======
ANSI_ESC_RE    = re.compile(r'\x1B\[[0-?]*[ -/]*[@-~]')
ANSI_SQUARE_RE = re.compile(r'\[(?:\d{1,3})(?:;\d{1,3})*m')

def _strip_ansi(s: str) -> str:
    s = ANSI_ESC_RE.sub('', s)
    s = ANSI_SQUARE_RE.sub('', s)
    return s

def render_cfg_mono(raw: str) -> str:
    clean = _strip_ansi(raw or "").replace("\r", "")
    clean = re.sub(r"[ \t]+", " ", clean).strip()
    if not clean:
        return "```\n(Tidak ada output)\n```"
    # pecah jika output masih dalam satu baris panjang
    if "\n" not in clean:
        # coba pecah dengan penanda umum agar lebih mudah dibaca
        keys = [
            r'◇', r'Username', r'Password', r'ISP', r'City', r'Host',
            r'Limit IP', r'Quota', r'Quota User', r'Masa Aktif', r'Expired On',
            r'OpenSSH', r'Dropbear', r'SSH WS', r'SSH SSL', r'SSL/TLS',
            r'Ovpn Ws', r'\bTCP\b', r'\bUDP\b', r'UDPGW', r'SLOWDNS',
            r'NAMESERVER', r'PUB KEY', r'\bWS\s*:', r'\bSSL\s*:', r'\bUDP\s*:'
        ]
        parts = re.split("|".join(fr"(?={k})" for k in keys), clean)
        lines = []
        for p in parts:
            p = p.strip()
            if not p: continue
            if " • " in p:
                lines.extend([x.strip() for x in p.split(" • ") if x.strip()])
            else:
                lines.append(p)
        clean = "\n".join(lines)
    return "```\n" + clean + "\n```"

# ===================== Data & tombol =====================
RENEW_CHOICES     = ["1","3","7","14","30","60","90"]
LIMIT_IP_CHOICES  = ["1","2","3","5","10","15","20","30","50"]
QUOTA_CHOICES     = ["1","3","5","10","15","20","30","50","100"]  # GB

def trojan_submenu_buttons():
    return [
        [Button.inline("🧪 Trial", b"trial7-trojan"),
         Button.inline("➕ Create", b"create7-trojan"),
         Button.inline("🟢 Online", b"cek7-trojan")],
        [Button.inline("🗑️ Delete", b"delete7-trojan"),
         Button.inline("🔓 Unlock", b"login7-trojan"),
         Button.inline("📉 Limit", b"limit7-trojan")],
        [Button.inline("♻️ Renew", b"renew7-trojan"),
         Button.inline("🧰 Restore", b"restore7-trojan"),
         Button.inline("📄 Cek Config", b"akun7-trojan")],
        [Button.inline("⬅️ Back", b"menu")]
    ]

def _nl_list(cmd):
    raw = _sh(cmd, "")
    items = []
    for line in raw.splitlines():
        line = line.strip()
        if ") " in line:
            num, rest = line.split(") ", 1)
            items.append((num.strip(), f"{num.strip()}) {rest.strip()}"))
    return items

def trj_users_active():
    # Ambil #trg dari config.json → "nl -s ') '"
    return _nl_list("cat /etc/xray/config.json | grep '^#trg' | cut -d ' ' -f 2-3 | nl -s ') '")

def trj_users_lockip():
    return _nl_list("cat /etc/trojan/listlock | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '")

def trj_users_lockgb():
    return _nl_list("cat /etc/trojan/userQuota | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '")

def trj_users_restore():
    return _nl_list("cat /etc/trojan/akundelete | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '")

def paginate_buttons(items, action, page=1, per_page=9, cancel_cb=b"trojan"):
    page  = max(1, page)
    start = (page - 1) * per_page
    chunk = items[start:start+per_page]
    rows  = []
    for idx, label in chunk:
        rows.append([Button.inline(label, f"trj:{action}:{idx}".encode())])
    total_pages = (len(items) + per_page - 1) // per_page if items else 1
    nav = []
    if page > 1:
        nav.append(Button.inline("⬅️ Prev", f"trj:page:{action}:{page-1}".encode()))
    if page < total_pages:
        nav.append(Button.inline("Next ➡️", f"trj:page:{action}:{page+1}".encode()))
    if nav:
        rows.append(nav)
    rows.append([Button.inline("❌ Cancel", cancel_cb)])
    return rows, total_pages

# ===================== CREATE (via chat) =====================
@bot.on(events.CallbackQuery(data=b'create7-trojan'))
async def create_trojan(event):
    async def go():
        chat   = event.chat_id
        sender = await event.get_sender()

        # Username
        await event.edit(
            box("🆕 CREATE TROJAN",
                ["Ketik **Username** (huruf/angka).", "• Tanpa spasi", "• Tidak boleh dobel nama"],
                "Kirim username di chat ini."),
            buttons=[[Button.inline("❌ Cancel", b"trojan")]]
        )
        async with bot.conversation(chat) as conv:
            ev = conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            username = (await ev).raw_text.strip()

        # Expired (days)
        await event.respond(
            box("⏳ Expired", ["Masukkan **Expired (hari)**:"], "Kirim angka hari."),
            buttons=[[Button.inline("❌ Cancel", b"trojan")]]
        )
        async with bot.conversation(chat) as conv:
            ev = conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            days = (await ev).raw_text.strip()

        # Limit IP
        await event.respond(
            box("📉 Limit IP", ["Masukkan **Limit IP Login** (angka):"], "Kirim angka."),
            buttons=[[Button.inline("❌ Cancel", b"trojan")]]
        )
        async with bot.conversation(chat) as conv:
            ev = conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            limit_ip = (await ev).raw_text.strip()

        # Quota
        await event.respond(
            box("🧱 Quota", ["Masukkan **Quota User (GB)**:"], "Kirim angka GB."),
            buttons=[[Button.inline("❌ Cancel", b"trojan")]]
        )
        async with bot.conversation(chat) as conv:
            ev = conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            quota = (await ev).raw_text.strip()

        subprocess.check_output(
            f'printf "%s\\n" "1" "{username}" "{days}" "{limit_ip}" "{quota}" | m-trojan | sleep 2 | exit',
            shell=True
        )
        await event.respond(
            box("✅ Berhasil", [f"Akun trojan dibuat: {username}"], "Pilih menu lain."),
            buttons=trojan_submenu_buttons()
        )

    if valid(str((await event.get_sender()).id)) == "true":
        await go()
    else:
        await event.answer("Akses Ditolak", alert=True)

# ===================== TRIAL (via chat) =====================
@bot.on(events.CallbackQuery(data=b'trial7-trojan'))
async def trial_trojan(event):
    async def go():
        chat   = event.chat_id
        sender = await event.get_sender()

        await event.edit(
            box("🧪 TRIAL TROJAN", ["Ketik **durasi trial (menit)**:"], "Kirim angka menit."),
            buttons=[[Button.inline("❌ Cancel", b"trojan")]]
        )
        async with bot.conversation(chat) as conv:
            ev = conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            minutes = (await ev).raw_text.strip()

        subprocess.check_output(
            f'printf "%s\\n" "2" "{minutes}" | m-trojan | sleep 2 | exit',
            shell=True
        )
        await event.respond(
            box("✅ Berhasil", [f"Trial dibuat: {minutes} menit."], "Pilih menu lain."),
            buttons=trojan_submenu_buttons()
        )

    if valid(str((await event.get_sender()).id)) == "true":
        await go()
    else:
        await event.answer("Akses Ditolak", alert=True)

# ===================== DELETE (tanpa ketik) =====================
@bot.on(events.CallbackQuery(data=b'delete7-trojan'))
async def delete_trojan(event):
    async def show(page=1):
        items = trj_users_active()
        msg   = box("🗑️ DELETE TROJAN", ["Pilih user yang akan dihapus:", "" if items else "(Tidak ada user)"], "Tap user.")
        btns, _ = paginate_buttons(items, "del", page, cancel_cb=b"trojan")
        await event.edit(msg, buttons=btns)

    if valid(str((await event.get_sender()).id)) == "true":
        await show()
    else:
        await event.answer("Akses Ditolak", alert=True)

# ===================== RENEW (tanpa ketik) =====================
@bot.on(events.CallbackQuery(data=b'renew7-trojan'))
async def renew_trojan(event):
    async def show(page=1):
        items = trj_users_active()
        msg   = box("♻️ RENEW TROJAN", ["Pilih user yang akan diperpanjang:"], "Tap user lalu pilih durasi.")
        btns, _ = paginate_buttons(items, "renew", page, cancel_cb=b"trojan")
        await event.edit(msg, buttons=btns)

    if valid(str((await event.get_sender()).id)) == "true":
        await show()
    else:
        await event.answer("Akses Ditolak", alert=True)

# ===================== LIMIT (tanpa ketik) =====================
@bot.on(events.CallbackQuery(data=b'limit7-trojan'))
async def limit_trojan(event):
    async def show(page=1):
        items = trj_users_active()
        msg   = box("📉 LIMIT TROJAN", ["Pilih user yang akan diubah limit & quota:"], "Tap user kemudian pilih nilai.")
        btns, _ = paginate_buttons(items, "limit", page, cancel_cb=b"trojan")
        await event.edit(msg, buttons=btns)

    if valid(str((await event.get_sender()).id)) == "true":
        await show()
    else:
        await event.answer("Akses Ditolak", alert=True)

# ===================== CEK CONFIG (monospace) =====================
@bot.on(events.CallbackQuery(data=b'akun7-trojan'))
async def akun_trojan(event):
    async def show(page=1):
        items = trj_users_active()
        msg   = box("📄 CEK CONFIG TROJAN", ["Pilih user untuk melihat config (monospace):"], "Tap user.")
        btns, _ = paginate_buttons(items, "cekcfg", page, cancel_cb=b"trojan")
        await event.edit(msg, buttons=btns)

    if valid(str((await event.get_sender()).id)) == "true":
        await show()
    else:
        await event.answer("Akses Ditolak", alert=True)

# ===================== RESTORE (tanpa ketik) =====================
@bot.on(events.CallbackQuery(data=b'restore7-trojan'))
async def restore_trojan(event):
    async def show(page=1):
        items = trj_users_restore()
        msg   = box("🧰 RESTORE TROJAN", ["Pilih akun yang akan di-restore:"], "Tap user, lalu pilih expired/limit/quota.")
        btns, _ = paginate_buttons(items, "restore", page, cancel_cb=b"trojan")
        await event.edit(msg, buttons=btns)

    if valid(str((await event.get_sender()).id)) == "true":
        await show()
    else:
        await event.answer("Akses Ditolak", alert=True)

# ===================== UNLOCK Submenu =====================
@bot.on(events.CallbackQuery(data=b'login7-trojan'))
async def login_submenu_trojan(event):
    if valid(str((await event.get_sender()).id)) != "true":
        return await event.answer("Access Denied", alert=True)

    inline = [
        [Button.inline("🔓 UNLOCK IP", b"loginip7-trojan"),
         Button.inline("🔓 UNLOCK QUOTA", b"logingb7-trojan")],
        [Button.inline("⬅️ Back", b"trojan")]
    ]
    await event.edit(box("🔓 UNLOCK MENU", ["Pilih jenis unlock:"]), buttons=inline)

@bot.on(events.CallbackQuery(data=b'loginip7-trojan'))
async def loginip_trojan(event):
    async def show(page=1):
        items = trj_users_lockip()
        msg   = box("🔓 UNLOCK MULTI LOGIN (IP)", ["Pilih user untuk di-unlock:", "" if items else "(Tidak ada user terkunci)"], "Tap user.")
        btns, _ = paginate_buttons(items, "unlockip", page, cancel_cb=b"login7-trojan")
        await event.edit(msg, buttons=btns)

    if valid(str((await event.get_sender()).id)) == "true":
        await show()
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'logingb7-trojan'))
async def logingb_trojan(event):
    async def show(page=1):
        items = trj_users_lockgb()
        msg   = box("🔓 UNLOCK QUOTA", ["Pilih user untuk di-unlock:", "" if items else "(Tidak ada user terkunci)"], "Tap user.")
        btns, _ = paginate_buttons(items, "unlockgb", page, cancel_cb=b"login7-trojan")
        await event.edit(msg, buttons=btns)

    if valid(str((await event.get_sender()).id)) == "true":
        await show()
    else:
        await event.answer("Akses Ditolak", alert=True)

# ===================== TROJAN ONLINE =====================
@bot.on(events.CallbackQuery(data=b'cek7-trojan'))
async def cek_trojan(event):
    async def go():
        out = _sh("bot-cek-tr", "")
        await event.edit(
            box("🟢 TROJAN USER ONLINE", [out if out else "(Tidak ada user online)"]),
            buttons=trojan_submenu_buttons()
        )

    if valid(str((await event.get_sender()).id)) == "true":
        await go()
    else:
        await event.answer("Access Denied", alert=True)

# ===================== SUBMENU TROJAN (tetap ada) =====================
@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
    async def trojan_(event):
        z = requests.get("http://ip-api.com/json/?fields=country,city,isp").json()
        total_tr = _sh("cat /etc/xray/config.json | grep '#trg' | wc -l", "0")
        msg = box(
            "🛡️ 𝐌𝐄𝐍𝐔 𝐓𝐑𝐎𝐉𝐀𝐍",
            [
                f"📈 Total Akun : {total_tr} akun",
                f"🏷️ Host       : {DOMAIN}",
                f"🌍 ISP        : {z.get('isp','-')}",
                f"🇺🇳 Country    : {z.get('country','-')}",
                f"🏙️ City       : {z.get('city','-')}",
                "",
                "Pilih tindakan di bawah:"
            ],
            "🤖 Bot by @AcilOffcial"
        )
        await event.edit(msg, buttons=trojan_submenu_buttons())

    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await trojan_(event)
    else:
        await event.answer("Access Denied", alert=True)

# ===================== ROUTER DINAMIS TROJAN (penutup stabil) =====================
@bot.on(events.CallbackQuery())
async def trojan_router(event):
    """
    Router dinamis untuk semua aksi 'trj:*'.
    Early-return jika data bukan prefix 'trj:' agar tidak ganggu handler lain.
    """
    data = event.data or b""
    if not data.startswith(b"trj:"):
        return

    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Akses Ditolak", alert=True)

    parts = data.decode().split(":")  # trj:action:...

    # ---- Paging ----
    if len(parts) == 4 and parts[1] == "page":
        action, page = parts[2], int(parts[3])
        if action == "del":
            items = trj_users_active()
            msg = box("🗑️ DELETE TROJAN", ["Pilih user:"], "Tap user.")
            btns, _ = paginate_buttons(items, "del", page)
            return await event.edit(msg, buttons=btns)
        if action == "renew":
            items = trj_users_active()
            msg = box("♻️ RENEW TROJAN", ["Pilih user:"], "Tap user.")
            btns, _ = paginate_buttons(items, "renew", page)
            return await event.edit(msg, buttons=btns)
        if action == "limit":
            items = trj_users_active()
            msg = box("📉 LIMIT TROJAN", ["Pilih user:"], "Tap user.")
            btns, _ = paginate_buttons(items, "limit", page)
            return await event.edit(msg, buttons=btns)
        if action == "cekcfg":
            items = trj_users_active()
            msg = box("📄 CEK CONFIG TROJAN", ["Pilih user:"], "Tap user.")
            btns, _ = paginate_buttons(items, "cekcfg", page)
            return await event.edit(msg, buttons=btns)
        if action == "restore":
            items = trj_users_restore()
            msg = box("🧰 RESTORE TROJAN", ["Pilih user:"], "Tap user.")
            btns, _ = paginate_buttons(items, "restore", page)
            return await event.edit(msg, buttons=btns)
        if action == "unlockip":
            items = trj_users_lockip()
            msg = box("🔓 UNLOCK IP", ["Pilih user:"], "Tap user.")
            btns, _ = paginate_buttons(items, "unlockip", page, cancel_cb=b"login7-trojan")
            return await event.edit(msg, buttons=btns)
        if action == "unlockgb":
            items = trj_users_lockgb()
            msg = box("🔓 UNLOCK QUOTA", ["Pilih user:"], "Tap user.")
            btns, _ = paginate_buttons(items, "unlockgb", page, cancel_cb=b"login7-trojan")
            return await event.edit(msg, buttons=btns)

    # ---- Delete ----
    if len(parts) == 3 and parts[1] == "del":
        idx = parts[2]
        subprocess.check_output(f'printf "%s\\n" "4" "{idx}" | m-trojan | sleep 2 | exit', shell=True)
        return await event.edit(box("✅ Dihapus", [f"User #{idx} dihapus."], "Selesai."), buttons=trojan_submenu_buttons())

    # ---- Renew ----
    if len(parts) == 3 and parts[1] == "renew":
        idx = parts[2]
        rows, row = [], []
        for i, d in enumerate(RENEW_CHOICES, 1):
            row.append(Button.inline(d, f"trj:renewset:{idx}:{d}".encode()))
            if i % 3 == 0:
                rows.append(row); row = []
        if row: rows.append(row)
        rows.append([Button.inline("❌ Cancel", b"renew7-trojan")])
        return await event.edit(box(f"♻️ Renew User #{idx}", ["Pilih durasi perpanjangan (hari):"]), buttons=rows)

    if len(parts) == 4 and parts[1] == "renewset":
        idx, days = parts[2], parts[3]
        subprocess.check_output(f'printf "%s\\n" "3" "{idx}" "{days}" | m-trojan | sleep 2 | exit', shell=True)
        return await event.edit(box("✅ Renew Berhasil", [f"User #{idx} diperpanjang {days} hari."], "Selesai."), buttons=trojan_submenu_buttons())

    # ---- Limit (IP -> Quota) ----
    if len(parts) == 3 and parts[1] == "limit":
        idx = parts[2]
        rows, row = [], []
        for i, ip in enumerate(LIMIT_IP_CHOICES, 1):
            row.append(Button.inline(ip, f"trj:limitip:{idx}:{ip}".encode()))
            if i % 3 == 0:
                rows.append(row); row = []
        if row: rows.append(row)
        rows.append([Button.inline("❌ Cancel", b"limit7-trojan")])
        return await event.edit(box(f"📉 Limit User #{idx}", ["Pilih Limit IP Login:"]), buttons=rows)

    if len(parts) == 4 and parts[1] == "limitip":
        idx, ip = parts[2], parts[3]
        rows, row = [], []
        for i, q in enumerate(QUOTA_CHOICES, 1):
            row.append(Button.inline(q, f"trj:limitset:{idx}:{ip}:{q}".encode()))
            if i % 3 == 0:
                rows.append(row); row = []
        if row: rows.append(row)
        rows.append([Button.inline("❌ Cancel", b"limit7-trojan")])
        return await event.edit(box(f"📦 Quota User #{idx}", [f"Limit IP: {ip}", "Pilih Quota (GB):"]), buttons=rows)

    if len(parts) == 5 and parts[1] == "limitset":
        idx, ip, quota = parts[2], parts[3], parts[4]
        subprocess.check_output(f'printf "%s\\n" "7" "{idx}" "{ip}" "{quota}" | m-trojan | sleep 2 | exit', shell=True)
        return await event.edit(box("✅ Limit/Quota Update", [f"User #{idx} → IP {ip}, Quota {quota} GB."], "Selesai."), buttons=trojan_submenu_buttons())

    # ---- Cek Config (monospace) ----
    if len(parts) == 3 and parts[1] == "cekcfg":
        idx = parts[2]
        raw = subprocess.check_output(f'printf "%s\\n" "6" "{idx}" | m-trojan | sleep 1 | exit', shell=True)\
                        .decode("utf-8", "ignore")
        return await event.edit(render_cfg_mono(raw), buttons=trojan_submenu_buttons())

    # ---- Unlock ----
    if len(parts) == 3 and parts[1] == "unlockip":
        idx = parts[2]
        subprocess.check_output(f'printf "%s\\n" "9" "{idx}" | m-trojan | sleep 2 | exit', shell=True)
        return await event.edit(box("✅ Unlock IP", [f"User #{idx} di-unlock."], "Selesai."), buttons=trojan_submenu_buttons())

    if len(parts) == 3 and parts[1] == "unlockgb":
        idx = parts[2]
        subprocess.check_output(f'printf "%s\\n" "10" "{idx}" | m-trojan | sleep 2 | exit', shell=True)
        return await event.edit(box("✅ Unlock Quota", [f"User #{idx} di-unlock."], "Selesai."), buttons=trojan_submenu_buttons())

    # ---- Restore (Expired -> Limit IP -> Quota) ----
    if len(parts) == 3 and parts[1] == "restore":
        idx = parts[2]
        rows, row = [], []
        for i, d in enumerate(RENEW_CHOICES, 1):
            row.append(Button.inline(d, f"trj:restexp:{idx}:{d}".encode()))
            if i % 3 == 0:
                rows.append(row); row = []
        if row: rows.append(row)
        rows.append([Button.inline("❌ Cancel", b"restore7-trojan")])
        return await event.edit(box(f"🧰 Restore User #{idx}", ["Pilih Expired (hari):"]), buttons=rows)

    if len(parts) == 4 and parts[1] == "restexp":
        idx, days = parts[2], parts[3]
        rows, row = [], []
        for i, ip in enumerate(LIMIT_IP_CHOICES, 1):
            row.append(Button.inline(ip, f"trj:restip:{idx}:{days}:{ip}".encode()))
            if i % 3 == 0:
                rows.append(row); row = []
        if row: rows.append(row)
        rows.append([Button.inline("❌ Cancel", b"restore7-trojan")])
        return await event.edit(box(f"🧰 Restore User #{idx}", [f"Expired dipilih: {days} hari", "Pilih Limit IP:"]), buttons=rows)

    if len(parts) == 5 and parts[1] == "restip":
        idx, days, ip = parts[2], parts[3], parts[4]
        rows, row = [], []
        for i, q in enumerate(QUOTA_CHOICES, 1):
            row.append(Button.inline(q, f"trj:restset:{idx}:{days}:{ip}:{q}".encode()))
            if i % 3 == 0:
                rows.append(row); row = []
        if row: rows.append(row)
        rows.append([Button.inline("❌ Cancel", b"restore7-trojan")])
        return await event.edit(box(f"🧰 Restore User #{idx}", [f"Expired: {days} hari, Limit IP: {ip}", "Pilih Quota (GB):"]), buttons=rows)

    if len(parts) == 6 and parts[1] == "restset":
        idx, days, ip, quota = parts[2], parts[3], parts[4], parts[5]
        subprocess.check_output(f'printf "%s\\n" "11" "{idx}" "{days}" "{ip}" "{quota}" | m-trojan | sleep 2 | exit', shell=True)
        return await event.edit(box("✅ Restore Berhasil", [f"User #{idx} → Exp {days} hari, IP {ip}, Quota {quota} GB."], "Selesai."), buttons=trojan_submenu_buttons())

    # Jika ada pola tidak dikenali: diam/abaikan agar stabil
    return