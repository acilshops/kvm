from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline(" 🔹𝚂𝚂𝙷🔹 ","ssh"),
Button.inline(" 🔹𝚅𝙼𝙴𝚂𝚂🔹 ","vmess")],
[Button.inline(" 🔹𝚅𝙻𝙴𝚂𝚂🔹 ","vless"),
Button.inline(" 🔹𝚃𝚁𝙾𝙹𝙰𝙽🔹 ","trojan")],
[Button.inline(" 🔹𝙽𝙾𝙾𝙱𝚉🔹 ","noobz"),
Button.inline(" 🔹𝚃𝚁-𝙶𝙾🔹 ","trojan-go")],
[Button.inline(" 🔹𝙸𝙽𝙵𝙾𝚅𝙿𝚂🔹 ","info"),
Button.inline(" 🔹𝚂𝙴𝚃𝚃𝙸𝙽𝙶🔹 ","setting")],
[Button.inline(" 🔹𝚁𝙴𝙶𝙸𝚂𝚃 𝙸𝙿🔹 ","regis")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		sh = f' cat /etc/xray/ssh | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		vm = f' cat /etc/xray/config.json | grep "#vmg" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		vl = f' cat /etc/xray/config.json | grep "#vlg" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		tr = f' cat /etc/xray/config.json | grep "#trg" | wc -l'
		trj = subprocess.check_output(tr, shell=True).decode("ascii")
		noob = f' cat /etc/xray/noob | grep "###" | wc -l'
		noobz = subprocess.check_output(noob, shell=True).decode("ascii")
		tgo = f' cat /etc/trojan-go/trgo | grep "###" | wc -l'
		trgo = subprocess.check_output(tgo, shell=True).decode("ascii")
		sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		ipvps = f" curl -s ipv4.icanhazip.com"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
		citsy = f" cat /etc/xray/city"
		city = subprocess.check_output(citsy, shell=True).decode("ascii")

		msg = f"""
**✧◇──────────────◇✧ **
      **💥⟨  𝙿𝙰𝙽𝙴𝙻 𝙱𝙾𝚃  ⟩💥**
**✧◇──────────────◇✧ **

**» 𝚆𝙴𝙻𝙻𝙲𝙾𝙼𝙴 𝙱𝚁𝙾 {sender.first_name} **

🔰 𝙾𝚂     :** `{namaos.strip().replace('"','')}`
🔰 𝙲𝙸𝚃𝚈 :** `{city.strip()}`
🔰 𝙳𝙾𝙼𝙰𝙸𝙽 :** `{DOMAIN}`
🔰 𝙸𝙿 𝚅𝙿𝚂 :** `{ipsaya.strip()}`
✧◇──────────────◇✧
       **⟨ 𝚃𝙾𝚃𝙰𝙻 𝙰𝙲𝙲𝙾𝚄𝙽𝚃 ⟩**
✧◇──────────────◇✧
»🔰 𝚂𝚂𝙷 𝙾𝚅𝙿𝙽  : `{ssh.strip()}` account
»🔰 𝚅𝙼𝙴𝚂𝚂  : `{vms.strip()}` account
»🔰 𝚅𝙻𝙴𝚂𝚂  : `{vls.strip()}` account
»🔰 𝚃𝚁𝙾𝙹𝙰𝙽  : `{trj.strip()}` account
»🔰 𝙽𝙾𝙾𝙱𝚉𝚅𝙿𝙽𝚂   : `{noobz.strip()}` account
»🔰 𝚃𝚁𝙾𝙹𝙰𝙽-𝙶𝙾   : `{trgo.strip()}` account
»🤖Bot by @AcilOffcial
✧◇──────────────◇✧ 
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
