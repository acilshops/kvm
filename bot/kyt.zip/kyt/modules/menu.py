from kyt import *
import subprocess
from telethon import events, Button

def _sh(cmd, default="-"):
    try:
        return subprocess.check_output(cmd, shell=True).decode().strip()
    except Exception:
        return default

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline("🧰 SSH", b"ssh"), Button.inline("⚡ VMESS", b"vmess")],
        [Button.inline("✨ VLESS", b"vless"), Button.inline("🛡️ TROJAN", b"trojan")],
        [Button.inline("🌀 NOOBZ", b"noobz"), Button.inline("🐉 TR-GO", b"trojan-go")],
        [Button.inline("🧾 INFO VPS", b"info"), Button.inline("⚙️ SETTING", b"setting")]
    ]

    sender = await event.get_sender()
    val = valid(str(sender.id))

    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
        return

    # ambil data server
    ssh   = _sh("cat /etc/xray/ssh | grep '###' | wc -l", "0")
    vms   = _sh("cat /etc/xray/config.json | grep '#vmg' | wc -l", "0")
    vls   = _sh("cat /etc/xray/config.json | grep '#vlg' | wc -l", "0")
    trj   = _sh("cat /etc/xray/config.json | grep '#trg' | wc -l", "0")
    noobz = _sh("cat /etc/xray/noob | grep '###' | wc -l", "0")
    trgo  = _sh("cat /etc/trojan-go/trgo | grep '###' | wc -l", "0")

    namaos = _sh("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'", "Unknown").replace('"','')
    ipsaya = _sh("curl -s ipv4.icanhazip.com", "0.0.0.0")
    city   = _sh("cat /etc/xray/city", "-")

    # format info box
    msg = f"""╭────────────────────
│   👋 𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐃𝐚𝐭𝐚𝐧𝐠 {sender.first_name}!
├────────────────────
│ 📦 𝐒𝐄𝐑𝐕𝐄𝐑 𝐈𝐍𝐅𝐎
│ 🖥️ OS      : {namaos}
│ 🗺️ City    : {city}
│ 🏷️ Domain  : {DOMAIN}
│ 🌐 IP VPS  : {ipsaya}
├────────────────────
│ 📊 𝐓𝐨𝐭𝐚𝐥 𝐀𝐤𝐮𝐧
│ • 🧰 SSH/OVPN  : {ssh} akun
│ • ⚡ VMESS     : {vms} akun
│ • ✨ VLESS     : {vls} akun
│ • 🛡️ TROJAN    : {trj} akun
│ • 🌀 NOOBZVPN  : {noobz} akun
│ • 🐉 TROJAN-GO : {trgo} akun
├────────────────────
│ 🤖@AcilOffcial
╰────────────────────
"""

    x = await event.edit(msg, buttons=inline)
    if not x:
        await event.reply(msg, buttons=inline)