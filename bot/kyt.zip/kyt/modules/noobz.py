from kyt import *
import subprocess, requests
from telethon import events, Button

# ============= Helpers umum (samakan gaya dgn SSH/Trojan) =============
def _sh(cmd, default=""):
    try:
        return subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8", "ignore").strip()
    except Exception:
        return default

def box(title, body_lines, footer=None):
    lines = ["╭────────────────────", f"│ {title}", "├────────────────────"]
    for ln in body_lines:
        for sub in str(ln).split("\n"):
            lines.append(f"│ {sub}")
    if footer:
        lines += ["├────────────────────", f"│ {footer}"]
    lines.append("╰────────────────────")
    return "\n".join(lines)

def paginate_buttons(items, action, page=1, per_page=9, cancel_cb=b"noobz"):
    page = max(1, page)
    start = (page - 1) * per_page
    chunk = items[start:start+per_page]
    rows = []
    for idx, label in chunk:
        rows.append([Button.inline(label, f"nbz:{action}:{idx}".encode())])
    total_pages = (len(items) + per_page - 1) // per_page if items else 1
    nav = []
    if page > 1:
        nav.append(Button.inline("⬅️ Prev", f"nbz:page:{action}:{page-1}".encode()))
    if page < total_pages:
        nav.append(Button.inline("Next ➡️", f"nbz:page:{action}:{page+1}".encode()))
    if nav:
        rows.append(nav)
    rows.append([Button.inline("❌ Cancel", cancel_cb)])
    return rows, total_pages

def noobz_submenu_buttons():
    return [
        [Button.inline("➕ Create", b"create-noobz"),
         Button.inline("🟢 Online", b"cek-noobz")],
        [Button.inline("🗑️ Delete", b"delete-noobz"),
         Button.inline("🔒 Lock", b"lock-noobz"),
         Button.inline("🔓 Unlock", b"unblock-noobz")],
        [Button.inline("⬅️ Back", b"menu")]
    ]

# ============= Data source NOOBZ =============
# daftar user aktif disimpan (mengikuti pola kamu) pada /etc/xray/noob
def noobz_users():
    raw = _sh("cat /etc/xray/noob | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '", "")
    items = []
    for line in raw.splitlines():
        line = line.strip()
        if ") " in line:
            num, rest = line.split(") ", 1)
            items.append((num.strip(), f"{num.strip()}) {rest.strip()}"))
    return items

# ============= MENU NOOBZ (utama) =============
@bot.on(events.CallbackQuery(data=b'noobz'))
async def noobz_menu(event):
    async def go():
        z = requests.get("http://ip-api.com/json/?fields=country,city,isp").json()
        total = _sh("cat /etc/xray/noob | grep '###' | wc -l", "0")
        msg = box(
            "🛡️ MENU NOOBZVPNS",
            [
                f"📈 Total Akun : {total} akun",
                f"🏷️ Host       : {DOMAIN}",
                f"🌍 ISP        : {z.get('isp','-')}",
                f"🇺🇳 Country    : {z.get('country','-')}",
                f"🏙️ City       : {z.get('city','-')}",
                "",
                "Pilih tindakan di bawah:"
            ],
            "🤖 Bot by @AcilOffcial"
        )
        await event.edit(msg, buttons=noobz_submenu_buttons())
    if valid(str((await event.get_sender()).id)) == "true":
        await go()
    else:
        await event.answer("Access Denied", alert=True)

# ============= CREATE (via chat, rapi) =============
@bot.on(events.CallbackQuery(data=b'create-noobz'))
async def create_noobz(event):
    async def go():
        chat = event.chat_id
        sender = await event.get_sender()

        header = box("🆕 CREATE NOOBZ", [
            "Ketik **Username** (huruf/angka).",
            "• Tanpa spasi",
            "• Tidak boleh dobel nama",
        ], "Kirim username di chat ini.")
        await event.edit(header, buttons=[[Button.inline("❌ Cancel", b"noobz")]])
        async with bot.conversation(chat) as conv:
            ev = conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            username = (await ev).raw_text.strip()

        await event.respond(box("🔑 Password", ["Ketik **Password** untuk akun:"], "Kirim password."), buttons=[[Button.inline("❌ Cancel", b"noobz")]])
        async with bot.conversation(chat) as conv:
            ev = conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            password = (await ev).raw_text.strip()

        await event.respond(box("⏳ Expired", ["Masukkan **Expired (hari)**:"], "Kirim angka hari."), buttons=[[Button.inline("❌ Cancel", b"noobz")]])
        async with bot.conversation(chat) as conv:
            ev = conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            days = (await ev).raw_text.strip()

        await event.respond(box("📉 Limit IP", ["Masukkan **Limit IP Login** (angka):"], "Kirim angka."), buttons=[[Button.inline("❌ Cancel", b"noobz")]])
        async with bot.conversation(chat) as conv:
            ev = conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            limit_ip = (await ev).raw_text.strip()

        # jalankan addnoobz
        subprocess.check_output(f'printf "%s\n" "{username}" "{password}" "{days}" "{limit_ip}" | addnoobz | sleep 2 | exit', shell=True)

        # Kirim ringkasan akun (gaya konsisten)
        summary = [
            "• TCP",
            f"Host       : {DOMAIN}",
            f"Username   : {username}",
            f"Password   : {password}",
            f"Limit IP   : {limit_ip}",
            "",
            "TCP_STD PORT  : 8080",
            "TCP_SSL PORT  : 8443",
            "",
            "⟨ Payload WS ⟩",
            "GET / HTTP/1.1[crlf]Host: [s_host][crlf]Upgrade: websocket[crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf][crlf]",
            "",
            f"Expired    : {days} hari"
        ]
        await event.respond(box("✅ Berhasil", summary, "Akun dibuat. Pilih menu lain."), buttons=noobz_submenu_buttons())
    if valid(str((await event.get_sender()).id)) == "true":
        await go()
    else:
        await event.answer("Akses Ditolak", alert=True)

# ============= DELETE (tanpa ketik, pakai tombol) =============
@bot.on(events.CallbackQuery(data=b'delete-noobz'))
async def delete_noobz(event):
    async def show(page=1):
        items = noobz_users()
        msg = box("🗑️ DELETE NOOBZ", ["Pilih user yang akan dihapus:", "" if items else "(Tidak ada user)"], "Tap tombol user.")
        btns, _ = paginate_buttons(items, "del", page, cancel_cb=b"noobz")
        await event.edit(msg, buttons=btns)
    if valid(str((await event.get_sender()).id)) == "true":
        await show()
    else:
        await event.answer("Akses Ditolak", alert=True)

# ============= LOCK (tanpa ketik) =============
@bot.on(events.CallbackQuery(data=b'lock-noobz'))
async def lock_noobz(event):
    async def show(page=1):
        items = noobz_users()
        msg = box("🔒 LOCK NOOBZ", ["Pilih user untuk di-lock (block):", "" if items else "(Tidak ada user)"], "Tap tombol user.")
        btns, _ = paginate_buttons(items, "lock", page, cancel_cb=b"noobz")
        await event.edit(msg, buttons=btns)
    if valid(str((await event.get_sender()).id)) == "true":
        await show()
    else:
        await event.answer("Akses Ditolak", alert=True)

# ============= UNLOCK (tanpa ketik) =============
@bot.on(events.CallbackQuery(data=b'unblock-noobz'))
async def unlock_noobz(event):
    async def show(page=1):
        items = noobz_users()
        msg = box("🔓 UNLOCK NOOBZ", ["Pilih user untuk di-unlock:", "" if items else "(Tidak ada user)"], "Tap tombol user.")
        btns, _ = paginate_buttons(items, "unlock", page, cancel_cb=b"noobz")
        await event.edit(msg, buttons=btns)
    if valid(str((await event.get_sender()).id)) == "true":
        await show()
    else:
        await event.answer("Akses Ditolak", alert=True)

# ============= CEK USER ONLINE =============
@bot.on(events.CallbackQuery(data=b'cek-noobz'))
async def cek_noobz(event):
    async def go():
        out = _sh("cek-noobz", "")
        await event.edit(box("🟢 NOOBZ USER ONLINE", [out if out else "(Tidak ada user online)"]), buttons=noobz_submenu_buttons())
    if valid(str((await event.get_sender()).id)) == "true":
        await go()
    else:
        await event.answer("Access Denied", alert=True)

# ============= ROUTER DINAMIS (aksi tombol) =============
@bot.on(events.CallbackQuery())
async def noobz_router(event):
    data = event.data or b""
    if not data.startswith(b"nbz:"):
        return

    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True); return

    parts = data.decode().split(":")  # nbz:action:...

    # Paging
    if len(parts) == 4 and parts[1] == "page":
        action, page = parts[2], int(parts[3])
        if action == "del":
            items = noobz_users()
            msg = box("🗑️ DELETE NOOBZ", ["Pilih user:"], "Tap user.")
            btns, _ = paginate_buttons(items, "del", page, cancel_cb=b"noobz")
            await event.edit(msg, buttons=btns); return
        if action == "lock":
            items = noobz_users()
            msg = box("🔒 LOCK NOOBZ", ["Pilih user:"], "Tap user.")
            btns, _ = paginate_buttons(items, "lock", page, cancel_cb=b"noobz")
            await event.edit(msg, buttons=btns); return
        if action == "unlock":
            items = noobz_users()
            msg = box("🔓 UNLOCK NOOBZ", ["Pilih user:"], "Tap user.")
            btns, _ = paginate_buttons(items, "unlock", page, cancel_cb=b"noobz")
            await event.edit(msg, buttons=btns); return

    # Delete → jalankan noobzvpns remove
    if len(parts) == 3 and parts[1] == "del":
        idx = parts[2]
        # Ambil username dari list (optional), tapi tool minta nomor.
        # CLI m-vmess/m-ssh pakai nomor; untuk noobz kita pakai username langsung.
        # Karena callback kita kirim idx nomor, kita butuh map nomor -> username:
        mapping = noobz_users()
        uname = None
        for k, label in mapping:
            if k == idx:
                # label "3) username", ambil teks setelah ") "
                uname = label.split(") ", 1)[1].split()[0]
                break
        if not uname:
            await event.answer("User tidak ditemukan.", alert=True); return
        subprocess.check_output(f'noobzvpns --remove-user {uname}', shell=True)
        await event.edit(box("✅ Dihapus", [f"User {uname} dihapus."], "Selesai."), buttons=noobz_submenu_buttons()); return

    # Lock → block-user
    if len(parts) == 3 and parts[1] == "lock":
        idx = parts[2]
        mapping = noobz_users()
        uname = None
        for k, label in mapping:
            if k == idx:
                uname = label.split(") ", 1)[1].split()[0]
                break
        if not uname:
            await event.answer("User tidak ditemukan.", alert=True); return
        subprocess.check_output(f'noobzvpns --block-user {uname}', shell=True)
        await event.edit(box("✅ Locked", [f"User {uname} di-lock."], "Selesai."), buttons=noobz_submenu_buttons()); return

    # Unlock → unblock-user  (PERBAIKAN dari kode lama)
    if len(parts) == 3 and parts[1] == "unlock":
        idx = parts[2]
        mapping = noobz_users()
        uname = None
        for k, label in mapping:
            if k == idx:
                uname = label.split(") ", 1)[1].split()[0]
                break
        if not uname:
            await event.answer("User tidak ditemukan.", alert=True); return
        subprocess.check_output(f'noobzvpns --unblock-user {uname}', shell=True)
        await event.edit(box("✅ Unlocked", [f"User {uname} di-unlock."], "Selesai."), buttons=noobz_submenu_buttons()); return