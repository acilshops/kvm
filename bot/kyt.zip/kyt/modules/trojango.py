from kyt import *
import subprocess, requests, re
from telethon import events, Button

# ===================== Helpers (samakan gaya SSH/Trojan) =====================
def _sh(cmd, default=""):
    try:
        return subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT)\
                         .decode("utf-8", "ignore").strip()
    except Exception:
        return default

def box(title, body_lines, footer=None):
    lines = ["╭────────────────────", f"│ {title}", "├────────────────────"]
    for ln in body_lines:
        for sub in ln.split("\n"):
            lines.append(f"│ {sub}")
    if footer:
        lines += ["├────────────────────", f"│ {footer}"]
    lines.append("╰────────────────────")
    return "\n".join(lines)

# Bersihkan ANSI agar output cek config tidak berantakan
ANSI_ESC_RE    = re.compile(r'\x1B\[[0-?]*[ -/]*[@-~]')
ANSI_SQUARE_RE = re.compile(r'\[(?:\d{1,3})(?:;\d{1,3})*m')
def _strip_ansi(s: str) -> str:
    s = ANSI_ESC_RE.sub('', s)
    s = ANSI_SQUARE_RE.sub('', s)
    return s

def render_cfg_mono_trgo(raw: str) -> str:
    clean = _strip_ansi(raw or "").replace("\r", "")
    clean = re.sub(r"[ \t]+", " ", clean).strip()
    if not clean:
        return "```\n(Tidak ada output)\n```"
    # pecah baris jika masih 1 baris panjang
    if "\n" not in clean:
        keys = [
            r'◇', r'Username', r'Password', r'Host', r'SNI', r'Bug',
            r'ISP', r'City', r'Expired', r'Expired On', r'Quota', r'Limit IP',
            r'WS', r'SSL', r'UDP', r'PAYLOAD', r'GET / HTTP/1.1'
        ]
        parts = re.split("|".join(fr"(?={k})" for k in keys), clean)
        lines = []
        for p in parts:
            p = p.strip()
            if not p: continue
            if " • " in p:
                lines.extend([x.strip() for x in p.split(" • ") if x.strip()])
            else:
                lines.append(p)
        clean = "\n".join(lines)
    return "```\n" + clean + "\n```"

# ===================== Data & Tombol =====================
RENEW_CHOICES = ["1","3","7","14","30","60","90"]

def trgo_submenu_buttons():
    return [
        [Button.inline("➕ Create", b"create-trgo"),
         Button.inline("📄 Cek Config", b"cek-trgo")],
        [Button.inline("🗑️ Delete", b"delete-trgo"),
         Button.inline("♻️ Renew",  b"renew-trgo")],
        [Button.inline("⬅️ Back",   b"menu")]
    ]

def _nl_list(cmd):
    raw = _sh(cmd, "")
    items = []
    for line in raw.splitlines():
        line = line.strip()
        if ") " in line:
            num, rest = line.split(") ", 1)
            items.append((num.strip(), f"{num.strip()}) {rest.strip()}"))
    return items

def trgo_users_active():
    # file daftar akun trojan-go (baris diawali ###), tampilkan nomor via nl
    return _nl_list("cat /etc/trojan-go/trgo | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '")

def paginate_buttons(items, action, page=1, per_page=9, cancel_cb=b"trojan-go"):
    page  = max(1, page)
    start = (page - 1) * per_page
    chunk = items[start:start+per_page]
    rows  = []
    for idx, label in chunk:
        rows.append([Button.inline(label, f"trgo:{action}:{idx}".encode())])
    total_pages = (len(items) + per_page - 1) // per_page if items else 1
    nav = []
    if page > 1:
        nav.append(Button.inline("⬅️ Prev", f"trgo:page:{action}:{page-1}".encode()))
    if page < total_pages:
        nav.append(Button.inline("Next ➡️", f"trgo:page:{action}:{page+1}".encode()))
    if nav:
        rows.append(nav)
    rows.append([Button.inline("❌ Cancel", cancel_cb)])
    return rows, total_pages

# ===================== MENU TROJAN-GO (utama) =====================
@bot.on(events.CallbackQuery(data=b'trojan-go'))
async def trgo_menu(event):
    async def trgo_menu_(event):
        z  = requests.get("http://ip-api.com/json/?fields=country,city,isp").json()
        n  = _sh("cat /etc/trojan-go/trgo | grep '###' | wc -l", "0")
        msg = box(
            "🛡️ 𝐌𝐄𝐍𝐔 𝐓𝐑𝐎𝐉𝐀𝐍-𝐆𝐎",
            [
                f"📈 Total Akun : {n} akun",
                f"🏷️ Host       : {DOMAIN}",
                f"🌍 ISP        : {z.get('isp','-')}",
                f"🇺🇳 Country    : {z.get('country','-')}",
                f"🏙️ City       : {z.get('city','-')}",
                "",
                "Pilih tindakan di bawah:"
            ],
            "🤖 Bot by @AcilOffcial"
        )
        await event.edit(msg, buttons=trgo_submenu_buttons())

    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await trgo_menu_(event)
    else:
        await event.answer("Access Denied", alert=True)

# ===================== CREATE (via chat, rapi) =====================
@bot.on(events.CallbackQuery(data=b'create-trgo'))
async def create_trgo(event):
    async def create_trgo_(event):
        chat   = event.chat_id
        sender = await event.get_sender()

        await event.edit(
            box("🆕 CREATE TROJAN-GO",
                ["Ketik **Username** (huruf/angka).", "• Tanpa spasi", "• Tidak boleh dobel nama"],
                "Kirim username di chat ini."),
            buttons=[[Button.inline("❌ Cancel", b"trojan-go")]]
        )
        async with bot.conversation(chat) as conv:
            ev = conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            username = (await ev).raw_text.strip()

        await event.respond(
            box("⏳ Expired", ["Masukkan **Expired (hari)**:"], "Kirim angka hari."),
            buttons=[[Button.inline("❌ Cancel", b"trojan-go")]]
        )
        async with bot.conversation(chat) as conv:
            ev = conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            days = (await ev).raw_text.strip()

        # m-trgo: 1=username, days
        subprocess.check_output(
            f'printf "%s\\n" "1" "{username}" "{days}" | m-trgo | sleep 2 | exit',
            shell=True
        )
        await event.respond(
            box("✅ Berhasil", [f"Akun TROJAN-GO dibuat: {username}"], "Pilih menu lain."),
            buttons=trgo_submenu_buttons()
        )

    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await create_trgo_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# ===================== DELETE (tanpa ketik) =====================
@bot.on(events.CallbackQuery(data=b'delete-trgo'))
async def delete_trgo(event):
    async def delete_trgo_(event, page=1):
        items = trgo_users_active()
        msg   = box("🗑️ DELETE TROJAN-GO", ["Pilih user yang akan dihapus:", "" if items else "(Tidak ada user)"], "Tap user.")
        btns, _ = paginate_buttons(items, "del", page, cancel_cb=b"trojan-go")
        await event.edit(msg, buttons=btns)

    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await delete_trgo_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# ===================== RENEW (tanpa ketik) =====================
@bot.on(events.CallbackQuery(data=b'renew-trgo'))
async def renew_trgo(event):
    async def renew_trgo_(event, page=1):
        items = trgo_users_active()
        msg   = box("♻️ RENEW TROJAN-GO", ["Pilih user yang akan diperpanjang:"], "Tap user lalu pilih durasi (hari).")
        btns, _ = paginate_buttons(items, "renew", page, cancel_cb=b"trojan-go")
        await event.edit(msg, buttons=btns)

    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await renew_trgo_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# ===================== CEK CONFIG (monospace, tanpa ketik) =====================
@bot.on(events.CallbackQuery(data=b'cek-trgo'))
async def cek_trgo(event):
    async def cek_trgo_(event, page=1):
        items = trgo_users_active()
        msg   = box("📄 CEK CONFIG TROJAN-GO", ["Pilih user untuk melihat config (monospace):"], "Tap user.")
        btns, _ = paginate_buttons(items, "cekcfg", page, cancel_cb=b"trojan-go")
        await event.edit(msg, buttons=btns)

    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await cek_trgo_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# ===================== ROUTER DINAMIS TROJAN-GO (penutup) =====================
@bot.on(events.CallbackQuery())
async def trgo_router(event):
    """
    Router dinamis untuk semua aksi 'trgo:*'.
    Early-return bila bukan prefix 'trgo:' agar tidak bentrok handler lain.
    """
    data = event.data or b""
    if not data.startswith(b"trgo:"):
        return

    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Akses Ditolak", alert=True)

    parts = data.decode().split(":")  # trgo:action:...

    # ---- Paging ----
    if len(parts) == 4 and parts[1] == "page":
        action, page = parts[2], int(parts[3])
        if action == "del":
            items = trgo_users_active()
            msg = box("🗑️ DELETE TROJAN-GO", ["Pilih user:"], "Tap user.")
            btns, _ = paginate_buttons(items, "del", page, cancel_cb=b"trojan-go")
            return await event.edit(msg, buttons=btns)
        if action == "renew":
            items = trgo_users_active()
            msg = box("♻️ RENEW TROJAN-GO", ["Pilih user:"], "Tap user.")
            btns, _ = paginate_buttons(items, "renew", page, cancel_cb=b"trojan-go")
            return await event.edit(msg, buttons=btns)
        if action == "cekcfg":
            items = trgo_users_active()
            msg = box("📄 CEK CONFIG TROJAN-GO", ["Pilih user:"], "Tap user.")
            btns, _ = paginate_buttons(items, "cekcfg", page, cancel_cb=b"trojan-go")
            return await event.edit(msg, buttons=btns)

    # ---- Delete ----
    if len(parts) == 3 and parts[1] == "del":
        idx = parts[2]
        subprocess.check_output(f'printf "%s\\n" "4" "{idx}" | m-trgo | sleep 2 | exit', shell=True)
        return await event.edit(box("✅ Dihapus", [f"User #{idx} dihapus."], "Selesai."),
                                buttons=trgo_submenu_buttons())

    # ---- Renew (pilih durasi) ----
    if len(parts) == 3 and parts[1] == "renew":
        idx = parts[2]
        rows, row = [], []
        for i, d in enumerate(RENEW_CHOICES, 1):
            row.append(Button.inline(d, f"trgo:renewset:{idx}:{d}".encode()))
            if i % 3 == 0:
                rows.append(row); row = []
        if row: rows.append(row)
        rows.append([Button.inline("❌ Cancel", b"renew-trgo")])
        return await event.edit(box(f"♻️ Renew User #{idx}", ["Pilih durasi perpanjangan (hari):"]), buttons=rows)

    if len(parts) == 4 and parts[1] == "renewset":
        idx, days = parts[2], parts[3]
        subprocess.check_output(f'printf "%s\\n" "3" "{idx}" "{days}" | m-trgo | sleep 2 | exit', shell=True)
        return await event.edit(box("✅ Renew Berhasil", [f"User #{idx} diperpanjang {days} hari."], "Selesai."),
                                buttons=trgo_submenu_buttons())

    # ---- Cek Config (monospace) ----
    if len(parts) == 3 and parts[1] == "cekcfg":
        idx = parts[2]
        raw = subprocess.check_output(f'printf "%s\\n" "6" "{idx}" | m-trgo | sleep 1 | exit', shell=True)\
                        .decode("utf-8", "ignore")
        return await event.edit(render_cfg_mono_trgo(raw), buttons=trgo_submenu_buttons())

    # Tidak dikenal → diam agar stabil
    return