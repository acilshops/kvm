from kyt import *
import subprocess, requests, re, os, shlex
from telethon import events, Button

# ===================== KONFIGURASI VLESS =====================
MVLESS_PATH = "/usr/bin/m-vless"   # Ganti jika beda
USE_SUDO    = False
CMD_TIMEOUT = 30
DEBUG_CLI   = False

# Nomor menu di m-vless.sh (ubah sesuai script kamu)
MENU_CREATE      = "1"
MENU_TRIAL       = "2"
MENU_RENEW_EXP   = "3"
MENU_DELETE      = "4"
MENU_CEKCFG      = "5"
MENU_SET_LIMITIP = "7"
MENU_UNLOCK_IP   = "9"
MENU_SET_QUOTA   = "10"

# Marker & file (ubah jika beda)
CONFIG_MARK_ACTIVE = r"^#vlg"        # baris user aktif di config.json
FILE_LOCK_IP       = "/etc/vless/listlock"
FILE_LOCK_GB       = "/etc/vless/userQuota"

# ===================== Util CLI =====================
def _sudo_prefix():
    return "sudo -n " if USE_SUDO else ""

def _ensure_cli_ready():
    if not os.path.exists(MVLESS_PATH):
        raise RuntimeError(f"m-vless tidak ditemukan: {MVLESS_PATH}")
    if not os.access(MVLESS_PATH, os.X_OK):
        raise RuntimeError(f"m-vless tidak executable: {MVLESS_PATH}")
    return True

def _run(cmd):
    if DEBUG_CLI: print("[CMD]", cmd)
    p = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=CMD_TIMEOUT)
    out = p.stdout.decode("utf-8", "ignore")
    if DEBUG_CLI and out.strip(): print("[OUT]\n", out)
    if p.returncode != 0:
        raise subprocess.CalledProcessError(p.returncode, cmd, output=out.encode("utf-8","ignore"))
    return out

def _printf(*lines) -> str:
    esc = [str(x).replace('"','\\"') for x in lines]
    return 'printf "%s\\n" "' + '" "'.join(esc) + '"'

def vless_call(*answers, add_press_any_key=True, add_exit=True):
    """
    Panggil m-vless dengan jawaban berurutan.
    Auto ENTER + 0 supaya tidak nyangkut di 'Press any key...'.
    """
    _ensure_cli_ready()
    payload = list(map(str, answers))
    if add_press_any_key: payload.append("")
    if add_exit:          payload.append("0")
    cmd = f'{_printf(*payload)} | {_sudo_prefix()}/bin/bash {shlex.quote(MVLESS_PATH)}'
    return _run(cmd)

# ===================== Helpers UI =====================
def _sh(cmd, default=""):
    try:
        return subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, timeout=CMD_TIMEOUT)\
                         .decode("utf-8", "ignore").strip()
    except Exception:
        return default

def box(title, body_lines, footer=None):
    lines = ["╭────────────────────", f"│ {title}", "├────────────────────"]
    for ln in body_lines:
        for sub in ln.split("\n"):
            lines.append(f"│ {sub}")
    if footer:
        lines += ["├────────────────────", f"│ {footer}"]
    lines.append("╰────────────────────")
    return "\n".join(lines)

ANSI_ESC_RE    = re.compile(r'\x1B\[[0-?]*[ -/]*[@-~]')
ANSI_SQUARE_RE = re.compile(r'\[(?:\d{1,3})(?:;\d{1,3})*m')
def _strip_ansi(s: str) -> str:
    s = ANSI_ESC_RE.sub('', s)
    s = ANSI_SQUARE_RE.sub('', s)
    return s

def render_cfg_mono(raw: str) -> str:
    clean = _strip_ansi(raw or "").replace("\r", "")
    clean = re.sub(r"[ \t]+", " ", clean).strip()
    return "```\n" + (clean or "(Tidak ada output)") + "\n```"

# ===================== Data & Tombol =====================
RENEW_CHOICES    = ["1","3","7","14","30","60","90"]
LIMIT_IP_CHOICES = ["1","2","3","5","10","15","20","30","50"]
QUOTA_CHOICES    = ["0","1","3","5","10","20","30","50","100"]  # 0 = Unlimited

def vless_menu_buttons():
    # mengikuti gaya SSH ringkas: Create, Trial, Online, Detail
    return [
        [Button.inline("➕ Create", b"vls-create"), Button.inline("🧪 Trial", b"vls-trial")],
        [Button.inline("🟢 Online", b"vls-online"), Button.inline("📚 Detail", b"vls-detail")],
        [Button.inline("⬅️ Back", b"menu")]
    ]

def _nl_list(cmd):
    raw = _sh(cmd, "")
    items = []
    for line in raw.splitlines():
        line = line.strip()
        if ") " in line:
            num, rest = line.split(") ", 1)
            items.append((num.strip(), f"{num.strip()}) {rest.strip()}"))
    return items

# daftar user aktif dari config.json
def vls_users_active():
    cmd = f"cat /etc/xray/config.json | grep '{CONFIG_MARK_ACTIVE}' | cut -d ' ' -f 2-3 | nl -s ') '"
    return _nl_list(cmd)

def vls_users_lockip():
    return _nl_list(f"cat {FILE_LOCK_IP} | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '")

def vls_users_lockgb():
    return _nl_list(f"cat {FILE_LOCK_GB} | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '")

def paginate_buttons(items, action, page=1, per_page=9, cancel_cb=b"vless"):
    page  = max(1, page)
    start = (page - 1) * per_page
    chunk = items[start:start+per_page]
    rows  = []
    for idx, label in chunk:
        rows.append([Button.inline(label, f"vls:{action}:{idx}".encode())])
    total_pages = (len(items) + per_page - 1) // per_page if items else 1
    nav = []
    if page > 1: nav.append(Button.inline("⬅️ Prev", f"vls:page:{action}:{page-1}".encode()))
    if page < total_pages: nav.append(Button.inline("Next ➡️", f"vls:page:{action}:{page+1}".encode()))
    if nav: rows.append(nav)
    rows.append([Button.inline("❌ Cancel", cancel_cb)])
    return rows, total_pages

# ===================== MENU VLESS (utama) =====================
@bot.on(events.CallbackQuery(data=b'vless'))
async def vless_menu(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Access Denied", alert=True)
    z  = requests.get("http://ip-api.com/json/?fields=country,city,isp").json()
    n  = _sh(f"cat /etc/xray/config.json | grep '{CONFIG_MARK_ACTIVE}' | wc -l", "0")
    msg = box(
        "⚡ 𝐌𝐄𝐍𝐔 𝐕𝐋𝐄𝐒𝐒",
        [
            f"📈 Total Akun : {n} akun",
            f"🏷️ Host       : {DOMAIN}",
            f"🌍 ISP        : {z.get('isp','-')}",
            f"🇺🇳 Country    : {z.get('country','-')}",
            f"🏙️ City       : {z.get('city','-')}",
            "",
            "Pilih tindakan di bawah:"
        ],
        "🤖 Bot by @AcilOffcial"
    )
    await event.edit(msg, buttons=vless_menu_buttons())

# ===================== CREATE (user → limit → quota → expired) =====================
@bot.on(events.CallbackQuery(data=b'vls-create'))
async def vls_create(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Akses Ditolak", alert=True)

    chat = event.chat_id

    await event.edit(box("🆕 CREATE VLESS",
                         ["Ketik **Username** (huruf/angka).", "• Tanpa spasi", "• Tidak boleh dobel nama"],
                         "Kirim username di chat ini."),
                     buttons=[[Button.inline("❌ Cancel", b"vless")]])
    async with bot.conversation(chat, timeout=120) as conv:
        ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        username = ev.raw_text.strip()

    await event.respond(box("📉 Limit IP", ["Masukkan **Limit IP Login** (angka):"], "Kirim angka."),
                        buttons=[[Button.inline("❌ Cancel", b"vless")]])
    async with bot.conversation(chat, timeout=120) as conv:
        ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        limit_ip = ev.raw_text.strip()

    await event.respond(box("📦 Quota (GB)", ["Masukkan **Quota (GB)**:", "• 0 = Unlimited"], "Kirim angka."),
                        buttons=[[Button.inline("❌ Cancel", b"vless")]])
    async with bot.conversation(chat, timeout=120) as conv:
        ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        quota = ev.raw_text.strip()

    await event.respond(box("⏳ Expired", ["Masukkan **Expired (hari)**:"], "Kirim angka hari."),
                        buttons=[[Button.inline("❌ Cancel", b"vless")]])
    async with bot.conversation(chat, timeout=120) as conv:
        ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        days = ev.raw_text.strip()

    try:
        # pola umum create vless: 1 username limit quota days
        vless_call(MENU_CREATE, username, limit_ip, quota, days)
    except Exception as e:
        msg = getattr(e, "output", b"").decode("utf-8","ignore") or str(e)
        return await event.respond(box("⚠️ Gagal Create", [msg], None), buttons=vless_menu_buttons())

    human_quota = "Unlimited" if quota == "0" else f"{quota} GB"
    await event.respond(
        box("✅ Berhasil",
            [f"User: {username}", f"Limit IP: {limit_ip}", f"Quota: {human_quota}", f"Expired: {days} hari}"],
            "Pilih menu lain."),
        buttons=vless_menu_buttons()
    )

# ===================== TRIAL =====================
@bot.on(events.CallbackQuery(data=b'vls-trial'))
async def vls_trial(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Akses Ditolak", alert=True)

    chat = event.chat_id
    await event.edit(box("🧪 TRIAL VLESS", ["Ketik **durasi trial (menit)**:"], "Kirim angka menit."),
                     buttons=[[Button.inline("❌ Cancel", b"vless")]])
    async with bot.conversation(chat, timeout=120) as conv:
        ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        minutes = ev.raw_text.strip()
    try:
        vless_call(MENU_TRIAL, minutes)
    except Exception as e:
        msg = getattr(e, "output", b"").decode("utf-8","ignore") or str(e)
        return await event.respond(box("⚠️ Gagal Trial", [msg], None), buttons=vless_menu_buttons())

    await event.respond(box("✅ Berhasil", [f"Trial dibuat: {minutes} menit."], "Pilih menu lain."), buttons=vless_menu_buttons())

# ===================== ONLINE (USER LOGIN) =====================
@bot.on(events.CallbackQuery(data=b'vls-online'))
async def vls_online(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Access Denied", alert=True)
    out = _sh("bot-cek-ws", "")
    await event.edit(box("🟢 VLESS USER ONLINE", [out if out else "(Tidak ada user online)"]), buttons=vless_menu_buttons())

# ===================== DETAIL (daftar user → submenu) =====================
@bot.on(events.CallbackQuery(data=b'vls-detail'))
async def vls_detail(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Akses Ditolak", alert=True)
    items = vls_users_active()
    msg   = box("📚 DETAIL VLESS", ["Pilih user untuk opsi Edit / Delete / Lock / Unlock:",
                                    "" if items else "(Tidak ada user)"], "Tap user.")
    btns, _ = paginate_buttons(items, "detail", page=1, cancel_cb=b"vless")
    await event.edit(msg, buttons=btns)

def detail_user_buttons(idx):
    return [
        [Button.inline("✏️ Edit",   f"vls:edit:{idx}".encode()),
         Button.inline("🗑️ Delete", f"vls:del:{idx}".encode())],
        [Button.inline("🔒 Lock IP",    f"vls:lockip:{idx}".encode()),
         Button.inline("🔓 Unlock IP",  f"vls:unlockip:{idx}".encode())],
        [Button.inline("📦 Quota",  f"vls:equota:{idx}".encode()),
         Button.inline("📄 Cek Config", f"vls:cekcfg:{idx}".encode())],
        [Button.inline("⬅️ Back", b"vls-detail")]
    ]

def edit_menu_buttons(idx):
    return [
        [Button.inline("📉 Limit IP", f"vls:elimit:{idx}".encode()),
         Button.inline("♻️ Renew",    f"vls:erenew:{idx}".encode())],
        [Button.inline("📦 Quota GB", f"vls:equota:{idx}".encode())],
        [Button.inline("⬅️ Back",     f"vls:detail:{idx}".encode())]
    ]

# ===================== ROUTER DINAMIS (vls:*) =====================
@bot.on(events.CallbackQuery())
async def vls_router(event):
    data = event.data or b""
    if not data.startswith(b"vls:"):
        return
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Akses Ditolak", alert=True)

    parts = data.decode().split(":")  # vls:action:...

    # Paging
    if len(parts) == 4 and parts[1] == "page":
        action, page = parts[2], int(parts[3])
        if action == "detail":
            items = vls_users_active()
            msg   = box("📚 DETAIL VLESS", ["Pilih user:"], "Tap user.")
            btns, _ = paginate_buttons(items, "detail", page, cancel_cb=b"vless")
            return await event.edit(msg, buttons=btns)

    # Detail user → submenu
    if len(parts) == 3 and parts[1] == "detail":
        idx = parts[2]
        # sebagian script menampilkan cfg ke layar; kita ambil ringkas bila ada
        info = _sh(f'{_printf(MENU_CEKCFG, idx, "", "0")} | {MVLESS_PATH} | head -n 40', "")
        msg  = box("👤 USER DETAIL", [(_strip_ansi(info)[:1200] or f"User #{idx}")], "Pilih aksi:")
        return await event.edit(msg, buttons=detail_user_buttons(idx))

    # Delete
    if len(parts) == 3 and parts[1] == "del":
        idx = parts[2]
        try:
            vless_call(MENU_DELETE, idx)
        except Exception as e:
            msg = getattr(e,"output",b"").decode("utf-8","ignore") or str(e)
            return await event.edit(box("⚠️ Gagal Hapus", [msg], None), buttons=vless_menu_buttons())
        return await event.edit(box("✅ Dihapus", [f"User #{idx} dihapus."], "Selesai."), buttons=vless_menu_buttons())

    # Edit submenu
    if len(parts) == 3 and parts[1] == "edit":
        idx = parts[2]
        return await event.edit(box(f"✏️ EDIT User #{idx}", ["Pilih item yang mau diubah:"], "Limit · Renew · Quota"),
                                buttons=edit_menu_buttons(idx))

    # Limit IP → pilih nilai → set (menu 7)
    if len(parts) == 3 and parts[1] == "elimit":
        idx = parts[2]
        rows, row = [], []
        for i, v in enumerate(LIMIT_IP_CHOICES, 1):
            row.append(Button.inline(v, f"vls:limitset:{idx}:{v}".encode()))
            if i % 3 == 0: rows.append(row); row=[]
        if row: rows.append(row)
        rows.append([Button.inline("⬅️ Back", f"vls:edit:{idx}".encode())])
        return await event.edit(box(f"📉 Limit IP User #{idx}", ["Pilih nilai Limit IP:"]), buttons=rows)

    if len(parts) == 4 and parts[1] == "limitset":
        idx, ip = parts[2], parts[3]
        try:
            vless_call(MENU_SET_LIMITIP, idx, ip)
        except Exception as e:
            msg = getattr(e,"output",b"").decode("utf-8","ignore") or str(e)
            return await event.edit(box("⚠️ Gagal Set Limit", [msg], None), buttons=vless_menu_buttons())
        return await event.edit(box("✅ Limit IP Diset", [f"User #{idx} → {ip}"], "Selesai."), buttons=vless_menu_buttons())

    # Renew expired (menu 3)
    if len(parts) == 3 and parts[1] == "erenew":
        idx = parts[2]
        rows, row = [], []
        for i, d in enumerate(RENEW_CHOICES, 1):
            row.append(Button.inline(d, f"vls:renewset:{idx}:{d}".encode()))
            if i % 3 == 0: rows.append(row); row=[]
        if row: rows.append(row)
        rows.append([Button.inline("⬅️ Back", f"vls:edit:{idx}".encode())])
        return await event.edit(box(f"♻️ Renew User #{idx}", ["Pilih durasi perpanjangan (hari):"]), buttons=rows)

    if len(parts) == 4 and parts[1] == "renewset":
        idx, days = parts[2], parts[3]
        try:
            vless_call(MENU_RENEW_EXP, idx, days)
        except Exception as e:
            msg = getattr(e,"output",b"").decode("utf-8","ignore") or str(e)
            return await event.edit(box("⚠️ Gagal Renew", [msg], None), buttons=vless_menu_buttons())
        return await event.edit(box("✅ Renew Berhasil", [f"User #{idx} diperpanjang {days} hari."], "Selesai."), buttons=vless_menu_buttons())

    # Quota (menu 10)
    if len(parts) == 3 and parts[1] == "equota":
        idx = parts[2]
        rows, row = [], []
        for i, q in enumerate(QUOTA_CHOICES, 1):
            row.append(Button.inline(q, f"vls:quotaset:{idx}:{q}".encode()))
            if i % 3 == 0: rows.append(row); row=[]
        if row: rows.append(row)
        rows.append([Button.inline("✏️ Custom", f"vls:quotaask:{idx}".encode())])
        rows.append([Button.inline("⬅️ Back", f"vls:edit:{idx}".encode())])
        return await event.edit(box(f"📦 Quota User #{idx}", ["Pilih Kuota (GB):", "0 = Unlimited"]), buttons=rows)

    if len(parts) == 4 and parts[1] == "quotaset":
        idx, gb = parts[2], parts[3]
        try:
            vless_call(MENU_SET_QUOTA, idx, gb)
        except Exception as e:
            msg = getattr(e,"output",b"").decode("utf-8","ignore") or str(e)
            return await event.edit(box("⚠️ Gagal Set Kuota", [msg], None), buttons=vless_menu_buttons())
        human = "Unlimited" if gb == "0" else f"{gb} GB"
        return await event.edit(box("✅ Kuota Diset", [f"User #{idx} → {human}."], "Selesai."), buttons=vless_menu_buttons())

    if len(parts) == 3 and parts[1] == "quotaask":
        idx   = parts[2]
        chat  = event.chat_id
        await event.edit(box("✏️ KUOTA CUSTOM", ["Ketik **angka kuota (GB)**:", "• 0 = Unlimited"], "Kirim angkanya."),
                         buttons=[[Button.inline("⬅️ Back", f"vls:equota:{idx}".encode())]])
        async with bot.conversation(chat, timeout=120) as conv:
            ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=(await event.get_sender()).id))
            gb = ev.raw_text.strip()
        try:
            vless_call(MENU_SET_QUOTA, idx, gb)
        except Exception as e:
            msg = getattr(e,"output",b"").decode("utf-8","ignore") or str(e)
            return await event.respond(box("⚠️ Gagal Set Kuota", [msg], None), buttons=vless_menu_buttons())
        human = "Unlimited" if gb == "0" else f"{gb} GB"
        return await event.respond(box("✅ Kuota Diset", [f"User #{idx} → {human}."], "Selesai."), buttons=vless_menu_buttons())

    # Lock / Unlock IP (menu 9 untuk unlock — sesuaikan bila perlu)
    if len(parts) == 3 and parts[1] == "lockip":
        idx = parts[2]
        # Jika script punya menu khusus lock, ubah di sini; fallback: set limit ke 0 (atau panggil helpermu)
        try:
            vless_call(MENU_SET_LIMITIP, idx, "0")  # interpretasi: 0 = lock / tak terbuka (sesuaikan)
        except Exception as e:
            msg = getattr(e,"output",b"").decode("utf-8","ignore") or str(e)
            return await event.edit(box("⚠️ Gagal Lock", [msg], None), buttons=vless_menu_buttons())
        return await event.edit(box("🔒 Locked", [f"User #{idx} dikunci (IP)."], None), buttons=vless_menu_buttons())

    if len(parts) == 3 and parts[1] == "unlockip":
        idx = parts[2]
        try:
            vless_call(MENU_UNLOCK_IP, idx)
        except Exception as e:
            msg = getattr(e,"output",b"").decode("utf-8","ignore") or str(e)
            return await event.edit(box("⚠️ Gagal Unlock", [msg], None), buttons=vless_menu_buttons())
        return await event.edit(box("🔓 Unlocked", [f"User #{idx} dibuka (IP)."], None), buttons=vless_menu_buttons())

    # Cek Config (menu 5)
    if len(parts) == 3 and parts[1] == "cekcfg":
        idx = parts[2]
        raw = _run(f'{_printf(MENU_CEKCFG, idx, "", "0")} | {_sudo_prefix()}/bin/bash {shlex.quote(MVLESS_PATH)}')
        return await event.edit(render_cfg_mono(raw), buttons=vless_menu_buttons())

    return