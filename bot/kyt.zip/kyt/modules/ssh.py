from kyt import *
import subprocess, requests, os, re
from telethon import events, Button

# ===================== KONFIGURASI =====================
MSSH = "/usr/bin/m-sshovpn"   # Ubah jika beda lokasi, contoh: /usr/local/bin/m-sshovpn
USE_SUDO = False              # True jika bot bukan root (pastikan sudoers sudah diatur)
DEBUG = False                 # True untuk melihat output command di log
CMD_TIMEOUT = 25              # detik, biar nggak hang

def _sudo_prefix():
    return "sudo -n " if USE_SUDO else ""

# ===================== Helpers =====================
def _run(cmd):
    """Jalankan command & kembalikan output (string)."""
    if DEBUG:
        print(f"[CMD] {cmd}")
    proc = subprocess.run(
        cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        timeout=CMD_TIMEOUT
    )
    text = proc.stdout.decode("utf-8", "ignore")
    if DEBUG and text.strip():
        print(f"[OUT]\n{text}")
    if proc.returncode != 0:
        raise subprocess.CalledProcessError(proc.returncode, cmd, output=text.encode("utf-8", "ignore"))
    return text

def _sh(cmd, default=""):
    try:
        return subprocess.check_output(
            cmd, shell=True, stderr=subprocess.STDOUT, timeout=CMD_TIMEOUT
        ).decode("utf-8", "ignore").strip()
    except Exception as e:
        if DEBUG:
            try:
                print(f"[SH-ERR] {e}\n{getattr(e, 'output', b'').decode('utf-8','ignore')}")
            except Exception:
                pass
        return default

def box(title, body_lines, footer=None):
    lines = ["╭────────────────────", f"│ {title}", "├────────────────────"]
    for ln in body_lines:
        for sub in ln.split("\n"):
            lines.append(f"│ {sub}")
    if footer:
        lines += ["├────────────────────", f"│ {footer}"]
    lines.append("╰────────────────────")
    return "\n".join(lines)

def ssh_submenu_buttons():
    # menu ringkas: Create, Trial, Login, Detail
    return [
        [Button.inline("➕ Create", b"create-ssh"),
         Button.inline("🧪 Trial", b"trial-ssh")],
        [Button.inline("🟢 Login", b"cek-ssh"),
         Button.inline("📚 Detail SSH", b"detail-ssh")],
        [Button.inline("⬅️ Back", b"menu")]
    ]

# ambil daftar user -> [(idx, "1) username"), ...]
def list_users_from(file_path):
    raw = _sh(f"cat {file_path} | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '", "")
    items = []
    if not raw:
        return items
    for line in raw.splitlines():
        line = line.strip()
        if ") " in line:
            num, rest = line.split(") ", 1)
            idx = num.strip()
            label = f"{idx}) {rest.strip()}"
            items.append((idx, label))
    return items

def get_index_for_username(username):
    raw = _sh("cat /etc/xray/ssh | grep '^###' | cut -d ' ' -f 2", "")
    if not raw:
        return None
    users = [u.strip() for u in raw.splitlines() if u.strip()]
    for i, u in enumerate(users, 1):
        if u == username:
            return str(i)
    return None

def read_user_line(username):
    if not username:
        return ""
    line = _sh(rf"grep -E '^###\s+{re.escape(username)}\s' /etc/xray/ssh", "")
    return line.strip()

def read_user_line_locked(username):
    if not username:
        return ""
    line = _sh(rf"grep -E '^###\s+{re.escape(username)}\s' /etc/xray/sshx/listlock", "")
    return line.strip()

def append_line(path, line):
    try:
        with open(path, "a") as f:
            f.write(line.rstrip() + "\n")
    except Exception:
        pass

def delete_line(path, line_regex):
    try:
        import regex as re2
    except Exception:
        import re as re2
    if not os.path.exists(path):
        return
    try:
        with open(path, "r") as f:
            lines = f.readlines()
        pat = re2.compile(line_regex)
        with open(path, "w") as f:
            for ln in lines:
                if not pat.search(ln):
                    f.write(ln)
    except Exception as e:
        if DEBUG:
            print(f"[delete_line-ERR] {e}")

# pagination util
def paginate_buttons(items, action, page=1, per_page=9, cancel_cb=b"ssh"):
    page = max(1, page)
    start = (page - 1) * per_page
    chunk = items[start:start+per_page]
    rows = []
    for idx, label in chunk:
        rows.append([Button.inline(label, f"ssh:{action}:{idx}".encode())])
    total_pages = (len(items) + per_page - 1) // per_page if items else 1
    nav = []
    if page > 1:
        nav.append(Button.inline("⬅️ Prev", f"ssh:page:{action}:{page-1}".encode()))
    if page < total_pages:
        nav.append(Button.inline("Next ➡️", f"ssh:page:{action}:{page+1}".encode()))
    if nav:
        rows.append(nav)
    rows.append([Button.inline("❌ Cancel", cancel_cb)])
    return rows, total_pages

# ===================== PEMBUNGKUS m-sshovpn =====================
def menu_call(*answers, auto_exit=True):
    """
    Panggil m-sshovpn dengan jawaban berurutan (stdin).
    auto_exit=True => tambahkan ENTER (untuk "Press any key") + 0 (keluar menu).
    """
    answers = [str(a) for a in answers]
    if auto_exit:
        answers = [*answers, "", "0"]   # ENTER untuk prompt "Press any key", lalu 0 untuk exit menu
    payload = '"\\n" "'.join([a.replace('"', '\\"') for a in answers])
    cmd = f'printf "%s\\n" "{payload}" | {_sudo_prefix()}/bin/bash {MSSH}'
    return _run(cmd)

# ===================== CREATE (tambah QUOTA) =====================
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    async def create_ssh_(event):
        chat = event.chat_id
        sender = await event.get_sender()

        prompt = box(
            "🆕 𝐂𝐑𝐄𝐀𝐓𝐄 𝐒𝐒𝐇",
            ["Ketik **Nama Akun** (huruf & angka).", "• Tanpa spasi", "• Tidak boleh dobel nama"],
            "Kirim nama akun di chat ini."
        )
        await event.edit(prompt, buttons=[[Button.inline("❌ Cancel", b"ssh")]])
        async with bot.conversation(chat) as conv:
            ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            username = ev.raw_text.strip()

        prompt2 = box("🔑 𝐏𝐚𝐬𝐬𝐰𝐨𝐫𝐝", ["Ketik **Password** untuk akun:"], "Kirim password di chat ini.")
        await event.respond(prompt2, buttons=[[Button.inline("❌ Cancel", b"ssh")]])
        async with bot.conversation(chat) as conv:
            ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            password = ev.raw_text.strip()

        prompt3 = box("📉 𝐋𝐢𝐦𝐢𝐭 𝐋𝐨𝐠𝐢𝐧 (IP)", ["Ketik **Limit IP Login** (angka):"], "Kirim angka limit.")
        await event.respond(prompt3, buttons=[[Button.inline("❌ Cancel", b"ssh")]])
        async with bot.conversation(chat) as conv:
            ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            limit_ip = ev.raw_text.strip()

        prompt4 = box("⏳ 𝐄𝐱𝐩𝐢𝐫𝐞𝐝", ["Ketik **Expired (hari)**:"], "Kirim angka hari.")
        await event.respond(prompt4, buttons=[[Button.inline("❌ Cancel", b"ssh")]])
        async with bot.conversation(chat) as conv:
            ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            days = ev.raw_text.strip()

        prompt5 = box("📦 𝐐𝐮𝐨𝐭𝐚 (GB)", ["Ketik **Quota (GB)**:", "• 0 = Unlimited"], "Kirim angka kuota.")
        await event.respond(prompt5, buttons=[[Button.inline("❌ Cancel", b"ssh")]])
        async with bot.conversation(chat) as conv:
            ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            quota_gb = ev.raw_text.strip()

        try:
            # 1) Buat akun (menu 1)
            menu_call("1", username, password, limit_ip, days)
            # 2) Set kuota (menu 10) pakai index user
            idx = get_index_for_username(username)
            human_quota = "(tidak di-set)"
            if idx and quota_gb.isdigit():
                menu_call("10", idx, quota_gb)
                human_quota = "Unlimited" if quota_gb == "0" else f"{quota_gb} GB"
        except subprocess.CalledProcessError as e:
            msg = e.output.decode("utf-8","ignore") or "Gagal create/set kuota."
            await event.respond(box("⚠️ Gagal", [msg], None), buttons=ssh_submenu_buttons())
            return

        done = box("✅ 𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥", [f"Akun SSH dibuat.", f"User: {username}", f"Quota: {human_quota}"], "Pilih menu lain di bawah.")
        await event.respond(done, buttons=ssh_submenu_buttons())

    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await create_ssh_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# ===================== TRIAL =====================
@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    async def trial_ssh_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        prompt = box("🧪 𝐓𝐑𝐈𝐀𝐋 𝐒𝐒𝐇", ["Ketik **durasi trial (menit)**:"], "Kirim angka menit.")
        await event.edit(prompt, buttons=[[Button.inline("❌ Cancel", b"ssh")]])
        async with bot.conversation(chat) as conv:
            ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            minutes = ev.raw_text.strip()
        try:
            menu_call("2", minutes)   # auto_exit=True akan ENTER + 0 sehingga tidak hang
        except subprocess.CalledProcessError as e:
            await event.respond(box("⚠️ Gagal", [e.output.decode("utf-8","ignore") or "Gagal membuat trial."], None), buttons=ssh_submenu_buttons())
            return
        done = box("✅ 𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥", [f"Trial dibuat: {minutes} menit."], "Silakan pilih menu lain.")
        await event.respond(done, buttons=ssh_submenu_buttons())

    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await trial_ssh_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# ===================== CEK USER ONLINE =====================
@bot.on(events.CallbackQuery(data=b'cek-ssh'))
async def login_ssh(event):
    async def login_ssh_(event):
        out = _sh("bot-cek-login-ssh", "")
        msg = box("🟢 𝐒𝐒𝐇 𝐔𝐒𝐄𝐑 𝐎𝐍𝐋𝐈𝐍𝐄", [out if out else "(Tidak ada user online)"])
        await event.edit(msg, buttons=ssh_submenu_buttons())
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await login_ssh_(event)
    else:
        await event.answer("Access Denied", alert=True)

# ===================== DETAIL SSH (daftar user -> submenu) =====================
@bot.on(events.CallbackQuery(data=b'detail-ssh'))
async def detail_ssh(event):
    async def detail_ssh_(event, page=1):
        items = list_users_from("/etc/xray/ssh")
        msg = box("📚 𝐃𝐄𝐓𝐀𝐈𝐋 𝐒𝐒𝐇",
                  ["Pilih user untuk melihat opsi:", "" if items else "(Tidak ada user)"],
                  "Tap salah satu user.")
        btns, _ = paginate_buttons(items, action="detail", page=page, cancel_cb=b"ssh")
        await event.edit(msg, buttons=btns)
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await detail_ssh_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# ===================== Pilihan Edit =====================
LIMIT_CHOICES = ["1","2","3","5","10","15","20","30","50"]
RENEW_CHOICES = ["1","3","7","14","30","60","90"]
QUOTA_CHOICES = ["0","1","2","5","10","20","50","100"]  # 0 = Unlimited

def user_detail_buttons(idx, username):
    return [
        [Button.inline("✏️ Edit", f"ssh:edit:{idx}:{username}".encode()),
         Button.inline("🗑️ Delete", f"ssh:del:{idx}".encode())],
        [Button.inline("🔒 Lock", f"ssh:lock:{idx}:{username}".encode()),
         Button.inline("🔓 Unlock", f"ssh:unlocku:{idx}:{username}".encode())],
        [Button.inline("⬅️ Back", b"detail-ssh")]
    ]

def edit_menu_buttons(idx, username):
    return [
        [Button.inline("📉 Limit IP", f"ssh:elimit:{idx}".encode()),
         Button.inline("♻️ Renew", f"ssh:erenew:{idx}".encode())],
        [Button.inline("📦 Quota GB", f"ssh:equota:{idx}".encode())],
        [Button.inline("⬅️ Back", f"ssh:detail:{idx}".encode())]
    ]

# ===================== ROUTER CALLBACK =====================
@bot.on(events.CallbackQuery())
async def ssh_dynamic_router(event):
    data = event.data or b""
    if not data.startswith(b"ssh:"):
        return
    parts = data.decode().split(":")

    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    # Paging detail list
    if len(parts) == 4 and parts[1] == "page":
        action, page = parts[2], int(parts[3])
        if action == "detail":
            items = list_users_from("/etc/xray/ssh")
            msg = box("📚 𝐃𝐄𝐓𝐀𝐈𝐋 𝐒𝐒𝐇", ["Pilih user:", "" if items else "(Tidak ada user)"], "Tap salah satu user.")
            btns, _ = paginate_buttons(items, action="detail", page=page, cancel_cb=b"ssh")
            await event.edit(msg, buttons=btns); return

    # Detail satu user -> submenu
    if len(parts) == 3 and parts[1] == "detail":
        idx = parts[2]
        label = _sh("cat /etc/xray/ssh | grep '^###' | cut -d ' ' -f 2 | nl -s ') '", "")
        username = None
        for line in label.splitlines():
            if line.startswith(f"{idx}) "):
                username = line.split(") ",1)[1].strip()
                break
        info = read_user_line(username) if username else ""
        msg = box("👤 𝐔𝐬𝐞𝐫 𝐃𝐞𝐭𝐚𝐢𝐥", [info or f"User #{idx}"], "Pilih aksi:")
        await event.edit(msg, buttons=user_detail_buttons(idx, username)); return

    # Delete (menu 4)
    if len(parts) == 3 and parts[1] == "del":
        idx = parts[2]
        try:
            menu_call("4", idx)
            await event.edit(box("✅ 𝐃𝐢𝐡𝐚𝐩𝐮𝐬", [f"User #{idx} dihapus."], "Pilih menu lain."), buttons=ssh_submenu_buttons())
        except subprocess.CalledProcessError as e:
            await event.edit(box("⚠️ Gagal Hapus", [e.output.decode("utf-8","ignore")], None), buttons=ssh_submenu_buttons())
        return

    # Edit submenu
    if len(parts) == 4 and parts[1] == "edit":
        idx, username = parts[2], parts[3]
        msg = box(f"✏️ 𝐄𝐝𝐢𝐭 {username}", ["Pilih item yang mau diubah:"], "Limit IP · Renew · Quota")
        await event.edit(msg, buttons=edit_menu_buttons(idx, username)); return

    # Edit: Limit IP
    if len(parts) == 3 and parts[1] == "elimit":
        idx = parts[2]
        rows, row = [], []
        for i, val in enumerate(LIMIT_CHOICES, 1):
            row.append(Button.inline(val, f"ssh:limitset:{idx}:{val}".encode()))
            if i % 3 == 0:
                rows.append(row); row = []
        if row: rows.append(row)
        rows.append([Button.inline("⬅️ Back", f"ssh:detail:{idx}".encode())])
        await event.edit(box("📉 𝐋𝐢𝐦𝐢𝐭 𝐈𝐏", ["Pilih nilai:"], None), buttons=rows); return

    if len(parts) == 4 and parts[1] == "limitset":
        idx, val = parts[2], parts[3]
        try:
            menu_call("7", idx, val)
            await event.edit(box("✅ 𝐋𝐢𝐦𝐢𝐭 𝐔𝐩𝐝𝐚𝐭𝐞", [f"User #{idx} → Limit {val}."], "Selesai."), buttons=ssh_submenu_buttons())
        except subprocess.CalledProcessError as e:
            await event.edit(box("⚠️ Gagal", [e.output.decode("utf-8","ignore")], None), buttons=ssh_submenu_buttons())
        return

    # Edit: Renew
    if len(parts) == 3 and parts[1] == "erenew":
        idx = parts[2]
        rows, row = [], []
        for i, d in enumerate(RENEW_CHOICES, 1):
            row.append(Button.inline(d, f"ssh:renewset:{idx}:{d}".encode()))
            if i % 3 == 0:
                rows.append(row); row = []
        if row: rows.append(row)
        rows.append([Button.inline("⬅️ Back", f"ssh:detail:{idx}".encode())])
        await event.edit(box("♻️ 𝐑𝐞𝐧𝐞𝐰", ["Pilih durasi (hari):"], None), buttons=rows); return

    if len(parts) == 4 and parts[1] == "renewset":
        idx, days = parts[2], parts[3]
        try:
            menu_call("3", idx, days)
            await event.edit(box("✅ 𝐑𝐞𝐧𝐞𝐰 𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥", [f"User #{idx} diperpanjang {days} hari."], "Selesai."), buttons=ssh_submenu_buttons())
        except subprocess.CalledProcessError as e:
            await event.edit(box("⚠️ Gagal", [e.output.decode("utf-8","ignore")], None), buttons=ssh_submenu_buttons())
        return

    # Edit: Quota
    if len(parts) == 3 and parts[1] == "equota":
        idx = parts[2]
        rows, row = [], []
        for i, gb in enumerate(QUOTA_CHOICES, 1):
            row.append(Button.inline(gb, f"ssh:quotaset:{idx}:{gb}".encode()))
            if i % 4 == 0:
                rows.append(row); row = []
        if row: rows.append(row)
        rows.append([Button.inline("✏️ Custom", f"ssh:quotaask:{idx}".encode())])
        rows.append([Button.inline("⬅️ Back", f"ssh:detail:{idx}".encode())])
        await event.edit(box("📦 𝐐𝐮𝐨𝐭𝐚 (GB)", ["Pilih kuota:", "0 = Unlimited"], None), buttons=rows); return

    if len(parts) == 4 and parts[1] == "quotaset":
        idx, gb = parts[2], parts[3]
        try:
            menu_call("10", idx, gb)
            human = "Unlimited" if gb == "0" else f"{gb} GB"
            await event.edit(box("✅ 𝐊𝐮𝐨𝐭𝐚 𝐃𝐢𝐬𝐞𝐭", [f"User #{idx} → {human}."], "Selesai."), buttons=ssh_submenu_buttons())
        except subprocess.CalledProcessError as e:
            await event.edit(box("⚠️ Gagal", [e.output.decode("utf-8","ignore")], None), buttons=ssh_submenu_buttons())
        return

    if len(parts) == 3 and parts[1] == "quotaask":
        idx = parts[2]
        chat = event.chat_id
        sender = await event.get_sender()
        prompt = box("✏️ 𝐊𝐮𝐨𝐭𝐚 𝐂𝐮𝐬𝐭𝐨𝐦", ["Ketik **angka kuota (GB)**:", "• 0 = Unlimited"], "Kirim angkanya.")
        await event.edit(prompt, buttons=[[Button.inline("⬅️ Back", f"ssh:detail:{idx}".encode())]])
        async with bot.conversation(chat) as conv:
            ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            gb = ev.raw_text.strip()
        try:
            menu_call("10", idx, gb)
            human = "Unlimited" if gb == "0" else f"{gb} GB"
            await event.respond(box("✅ 𝐊𝐮𝐨𝐭𝐚 𝐃𝐢𝐬𝐞𝐭", [f"User #{idx} → {human}."], "Selesai."), buttons=ssh_submenu_buttons())
        except subprocess.CalledProcessError as e:
            await event.respond(box("⚠️ Gagal", [e.output.decode("utf-8","ignore")], None), buttons=ssh_submenu_buttons())
        return

    # Lock user (langsung lock akun)
    if len(parts) == 4 and parts[1] == "lock":
        idx, username = parts[2], parts[3]
        info = read_user_line(username)
        if info:
            _sh(f"{_sudo_prefix()}passwd -l {username}")
            append_line("/etc/xray/sshx/listlock", info)
            user_re = rf"^###\s+{re.escape(username)}\s+"
            delete_line("/etc/xray/ssh", user_re)
            await event.edit(box("🔒 𝐋𝐨𝐜𝐤", [f"{username} terkunci."], None), buttons=ssh_submenu_buttons()); return
        await event.edit(box("⚠️", [f"Gagal lock: {username} tidak ditemukan"], None), buttons=ssh_submenu_buttons()); return

    # Unlock user (langsung buka)
    if len(parts) == 4 and parts[1] == "unlocku":
        idx, username = parts[2], parts[3]
        info = read_user_line_locked(username)
        if info:
            _sh(f"{_sudo_prefix()}passwd -u {username}")
            append_line("/etc/xray/ssh", info)
            user_re = rf"^###\s+{re.escape(username)}\s+"
            delete_line("/etc/xray/sshx/listlock", user_re)
            await event.edit(box("🔓 𝐔𝐧𝐥𝐨𝐜𝐤", [f"{username} dibuka."], None), buttons=ssh_submenu_buttons()); return
        else:
            _sh(f"{_sudo_prefix()}passwd -u {username}")
            await event.edit(box("🔓 𝐔𝐧𝐥𝐨𝐜𝐤", [f"{username} dibuka (no listlock)."], None), buttons=ssh_submenu_buttons()); return

# ===================== SUBMENU SSH =====================
@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
    async def ssh_(event):
        z = requests.get("http://ip-api.com/json/?fields=country,city,isp").json()
        total_ssh = _sh("cat /etc/xray/ssh | grep '###' | wc -l", "0")
        msg = box(
            "🔐 𝐌𝐄𝐍𝐔 𝐒𝐒𝐇",
            [
                f"📈 Total Akun : {total_ssh} akun",
                f"🏷️ Host       : {DOMAIN}",
                f"🌍 ISP        : {z.get('isp','-')}",
                f"🇺🇳 Country    : {z.get('country','-')}",
                f"🏙️ City       : {z.get('city','-')}",
                "",
                "Pilih tindakan di bawah:"
            ],
            "🤖 Bot by @AcilOffcial"
        )
        await event.edit(msg, buttons=ssh_submenu_buttons())

    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await ssh_(event)
    else:
        await event.answer("Access Denied", alert=True)