from kyt import *

#delete
@bot.on(events.CallbackQuery(data=b'delete7-vless'))
async def delete_vless(event):
	async def delete_vless_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^#vlg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ LIST DELETE USER**
{z}
**👉 Input Your Number :**
/cancel Kembali KeMENU
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			cmd = f'printf "%s\n" "4" "{user}" | m-vless | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» SUCCES**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#renew
@bot.on(events.CallbackQuery(data=b'renew7-vless'))
async def renew_vless(event):
	async def renew_vless_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^#vlg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ LIST RENEW USER**
{z}
**👉 Input Your Number :**
/cancel Kembali KeMENU
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**👉 Input Your New Expired (day) :**
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			cmd = f'printf "%s\n" "3" "{user}" "{exp}" | m-vless | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» SUCCES**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await renew_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)


#limit
@bot.on(events.CallbackQuery(data=b'limit7-vless'))
async def limit_vless(event):
	async def limit_vless_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^#vlg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ CHANGE LIMIT USER**
{z}
**👉 Input Your Number :**
/cancel Kembali KeMENU
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**👉 Input Your New Limit IP Login :**
0 For Unlimited
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			async with bot.conversation(chat) as pw:
				await event.respond(f"""
**👉 Input Your New Quota User :**
0 For Unlimited
""")
				pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw = (await pw).raw_text
			cmd = f'printf "%s\n" "7" "{user}" "{exp}" "{pw}" | m-vless | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» SUCCES CHANGE**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await limit_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#CekConfig
@bot.on(events.CallbackQuery(data=b'akun7-vless'))
async def akun_vless(event):
	async def akun_vless_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^#vlg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ CEK CONFIG USER**
{z}
**👉 Input Your Number :**
/cancel Kembali KeMENU
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			cmd = f'printf "%s\n" "6" "{user}" | m-vless | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» SUCCES CEK AKUN**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await akun_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
		
#restore
@bot.on(events.CallbackQuery(data=b'restore7-vless'))
async def restore_vless(event):
	async def restore_vless_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/vless/akundelete | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ LIST AKUN RESTORE **
{z}
**👉 Input Your Number :**
/cancel Kembali KeMENU
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**👉 Input Your Expired (day) :**
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			async with bot.conversation(chat) as pw:
				await event.respond(f"""
**👉 Input Your New Limit IP Login :**
0 For Unlimited
""")
				pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw = (await pw).raw_text
			async with bot.conversation(chat) as pw2:
				await event.respond(f"""
**👉 Input Your New Quota User:**
0 For Unlimited
""")
				pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw2 = (await pw2).raw_text
			cmd = f'printf "%s\n" "11" "{user}" "{exp}" "{pw}" "{pw2}" | m-vless | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» SUCCES CHANGE**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await restore_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)


#MultiLogin Login
@bot.on(events.CallbackQuery(data=b'loginip7-vless'))
async def loginip_vless(event):
	async def loginip_vless_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/vless/listlock | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ LIST MULTI LOGIN IP USER**
{z}
**👉 Input Your Number :**
/cancel Kembali KeMENU
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			cmd = f'printf "%s\n" "9" "{user}" | m-vless | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» SUCCES UNLOCK**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await loginip_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
#MultiLogin Quota
@bot.on(events.CallbackQuery(data=b'logingb7-vless'))
async def logingb_vless(event):
	async def logingb_vless_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/vless/userQuota | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ LIST LOGIN QUOTA USER**
{z}
**👉 Input Your Number :**
/cancel Kembali KeMENU
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			cmd = f'printf "%s\n" "10" "{user}" | m-vless | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» SUCCES UNLOCK**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await logingb_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
#CRATE VLESS
@bot.on(events.CallbackQuery(data=b'create7-vless'))
async def create_vless(event):
	async def create_vless_(event):
		async with bot.conversation(chat) as user:
			await event.edit(f"""
**✨ 𝙽𝚊𝚖𝚊 𝚋𝚎𝚛𝚞𝚙𝚊 𝚌𝚊𝚖𝚙𝚞𝚛𝚊𝚗, 
 𝙷𝚞𝚛𝚞𝚏 𝚔𝚊𝚙𝚒𝚝𝚊𝚕, 𝚍𝚊𝚗 𝙰𝚗𝚐𝚔𝚊**
**✨ No Space**
**✨ No double Name**
**✨ Bot : @AcilOffcial**

**👉 Input Your UserName :**
/cancel Kembali KeMENU
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**👉 Input Your Expired (day) :**
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			async with bot.conversation(chat) as pw:
				await event.respond(f"""
**👉 Input Your Limit IP Login :**
0 For Unlimited
""")
				pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw = (await pw).raw_text
			async with bot.conversation(chat) as pw2:
				await event.respond(f"""
**👉 Input Your Quota User :**
0 For Unlimited
""")
				pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw2 = (await pw2).raw_text
			cmd = f'printf "%s\n" "1" "{user}" "{exp}" "{pw}" "{pw2}" | m-vless | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» SUCCES CREATE**
**» DONE**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

# TRIAL vless
@bot.on(events.CallbackQuery(data=b'trial7-vless'))
async def trial_vless(event):
	async def trial_vless_(event):
		async with bot.conversation(chat) as exp:
			await event.edit(f"""
**👉 Input Your Timer (Minutes) :**
/cancel Kembali KeMENU
""")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		per = "/cancel"
		if exp == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			cmd = f'printf "%s\n" {2} "{exp}" | m-vless | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True).decode("utf-8")
			await event.respond(f"""
**» SUCCES CREATE**
**» DONE**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#CEK
@bot.on(events.CallbackQuery(data=b'cek7-vless'))
async def cek_vless(event):
	async def cek_vless_(event):
		cmd = 'bot-cek-vless'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.edit(f"""
**⚠️ VLESS USER ONLINE**
{z}
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_vless_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'login7-vless'))
async def vless(event):
	async def vless_(event):
		inline = [
[Button.inline(" UNLOCK LOGIN ","loginip7-vless"),
Button.inline(" UNLOCK QUOTA ","logingb7-vless")],
[Button.inline("‹ Back ›","vless")]]
		await event.edit(buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vless_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
@bot.on(events.CallbackQuery(data=b'vless'))
async def vless(event):
	async def vless_(event):
		inline = [
[Button.inline(" Trial ","trial7-vless"),
Button.inline(" Create ","create7-vless"),
Button.inline(" Login ","cek7-vless")],
[Button.inline(" Delete ","delete7-vless"),
Button.inline(" Unlock ","login7-vless"),from kyt import *
import subprocess, requests, re, os, shlex, time

# ===================== KONFIGURASI VLESS =====================
MVLESS_PATH = "/usr/bin/m-vless"   # Ganti jika beda lokasi
USE_SUDO    = False
CMD_TIMEOUT = 30
DEBUG_CLI   = False

# Nomor menu di m-vless.sh (UBAH jika skripmu beda)
MENU_CREATE      = "1"   # create: username, limit_ip, quota_gb, days
MENU_TRIAL       = "2"   # trial: minutes
MENU_RENEW_EXP   = "3"   # renew expired: idx, days
MENU_DELETE      = "4"   # delete: idx
MENU_CEKCFG      = "6"   # cek config: idx
MENU_SET_LIMIPQ  = "7"   # set limit &/ quota: idx, ip, quota (jika skripmu hanya ip, tetap pakai ini utk IP saja)
MENU_UNLOCK_IP   = "9"   # unlock multi-login IP: idx
MENU_SET_QUOTA   = "10"  # set/renew quota (GB): idx, gb
MENU_RESTORE     = "11"  # restore: idx, days, ip, quota

# Marker / file (UBAH jika beda)
CONFIG_MARK_ACTIVE = r"^#vlg"
FILE_LOCK_IP       = "/etc/vless/listlock"
FILE_LOCK_GB       = "/etc/vless/userQuota"
FILE_RESTORE       = "/etc/vless/akundelete"

# ===================== CLI Wrapper =====================
def _sudo_prefix():
    return "sudo -n " if USE_SUDO else ""

def _ensure_cli_ready():
    if not os.path.exists(MVLESS_PATH):
        raise RuntimeError(f"m-vless tidak ditemukan: {MVLESS_PATH}")
    if not os.access(MVLESS_PATH, os.X_OK):
        raise RuntimeError(f"m-vless tidak executable: {MVLESS_PATH}")
    return True

def _run(cmd):
    if DEBUG_CLI: print("[CMD]", cmd)
    p = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=CMD_TIMEOUT)
    out = p.stdout.decode("utf-8", "ignore")
    if DEBUG_CLI and out.strip(): print("[OUT]\n", out)
    if p.returncode != 0:
        raise subprocess.CalledProcessError(p.returncode, cmd, output=out.encode("utf-8","ignore"))
    return out

def _printf(*lines) -> str:
    esc = [str(x).replace('"','\\"') for x in lines]
    return 'printf "%s\\n" "' + '" "'.join(esc) + '"'

def vless_call(*answers, add_press_any_key=True, add_exit=True):
    _ensure_cli_ready()
    payload = list(map(str, answers))
    if add_press_any_key: payload.append("")  # ENTER utk �Press any key��
    if add_exit:          payload.append("0") # kembali ke menu
    cmd = f'{_printf(*payload)} | {_sudo_prefix()}/bin/bash {shlex.quote(MVLESS_PATH)}'
    return _run(cmd)

# ===================== Helpers UI =====================
def _sh(cmd, default=""):
    try:
        return subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, timeout=CMD_TIMEOUT)\
                         .decode("utf-8", "ignore").strip()
    except Exception:
        return default

def box(title, body_lines, footer=None):
    lines = ["", f" {title}", ""]
    for ln in body_lines:
        for sub in ln.split("\n"):
            lines.append(f" {sub}")
    if footer:
        lines += ["", f" {footer}"]
    lines.append("")
    return "\n".join(lines)

ANSI_ESC_RE    = re.compile(r'\x1B\[[0-?]*[ -/]*[@-~]')
ANSI_SQUARE_RE = re.compile(r'\[(?:\d{1,3})(?:;\d{1,3})*m')
def _strip_ansi(s: str) -> str:
    s = ANSI_ESC_RE.sub('', s)
    s = ANSI_SQUARE_RE.sub('', s)
    return s

def render_cfg_mono(raw: str) -> str:
    clean = _strip_ansi(raw or "").replace("\r", "")
    clean = re.sub(r"[ \t]+", " ", clean).strip()
    return "```\n" + (clean or "(Tidak ada output)") + "\n```"

# ===================== Data & Tombol =====================
RENEW_CHOICES    = ["1","3","7","14","30","60","90"]
LIMIT_IP_CHOICES = ["1","2","3","5","10","15","20","30","50"]
QUOTA_CHOICES    = ["0","1","3","5","10","20","30","50","100"]  # 0 = Unlimited

def vless_menu_buttons():
    return [
        [Button.inline(" Create", b"vls-create"), Button.inline(" Trial", b"vls-trial")],
        [Button.inline(" Online", b"vls-online"), Button.inline(" Detail", b"vls-detail")],
        [Button.inline(" Back", b"menu")]
    ]

def _nl_list(cmd):
    raw = _sh(cmd, "")
    items = []
    for line in raw.splitlines():
        line = line.strip()
        if ") " in line:
            num, rest = line.split(") ", 1)
            items.append((num.strip(), f"{num.strip()}) {rest.strip()}"))
    return items

def vls_users_active():
    cmd = f"cat /etc/xray/config.json | grep '{CONFIG_MARK_ACTIVE}' | cut -d ' ' -f 2-3 | nl -s ') '"
    return _nl_list(cmd)

def vls_users_lockip():
    return _nl_list(f"cat {FILE_LOCK_IP} | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '")

def vls_users_lockgb():
    return _nl_list(f"cat {FILE_LOCK_GB} | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '")

def vls_users_restore():
    return _nl_list(f"cat {FILE_RESTORE} | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '")

def paginate_buttons(items, action, page=1, per_page=9, cancel_cb=b"vless"):
    page  = max(1, page)
    start = (page - 1) * per_page
    chunk = items[start:start+per_page]
    rows  = []
    for idx, label in chunk:
        rows.append([Button.inline(label, f"vls:{action}:{idx}".encode())])
    total_pages = (len(items) + per_page - 1) // per_page if items else 1
    nav = []
    if page > 1: nav.append(Button.inline(" Prev", f"vls:page:{action}:{page-1}".encode()))
    if page < total_pages: nav.append(Button.inline("Next ", f"vls:page:{action}:{page+1}".encode()))
    if nav: rows.append(nav)
    rows.append([Button.inline(" Cancel", cancel_cb)])
    return rows, total_pages

# ===================== MENU VLESS (utama) =====================
@bot.on(events.CallbackQuery(data=b'vless'))
async def vless_menu(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Access Denied", alert=True)
    z  = requests.get("http://ip-api.com/json/?fields=country,city,isp").json()
    n  = _sh(f"cat /etc/xray/config.json | grep '{CONFIG_MARK_ACTIVE}' | wc -l", "0")
    msg = box(
        " MENU VLESS",
        [
            f" Total Akun : {n} akun",
            f" Host       : {DOMAIN}",
            f" ISP        : {z.get('isp','-')}",
            f" Country    : {z.get('country','-')}",
            f" City       : {z.get('city','-')}",
            "",
            "Pilih tindakan di bawah:"
        ],
        " Bot by @AcilOffcial"
    )
    await event.edit(msg, buttons=vless_menu_buttons())

# ===================== CREATE (user  limit  quota  expired + progress) =====================
@bot.on(events.CallbackQuery(data=b'vls-create'))
async def vls_create(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Akses Ditolak", alert=True)

    chat = event.chat_id

    await event.edit(
        box(" CREATE VLESS",
            ["Ketik Username (huruf/angka).", "� Tanpa spasi", "� Tidak boleh dobel nama"],
            "Kirim username di chat ini."),
        buttons=[[Button.inline(" Cancel", b"vless")]]
    )
    async with bot.conversation(chat, timeout=120) as conv:
        ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        username = ev.raw_text.strip()

    await event.respond(box(" Limit IP", ["Masukkan Limit IP Login (angka):"], "Kirim angka."),
                        buttons=[[Button.inline(" Cancel", b"vless")]])
    async with bot.conversation(chat, timeout=120) as conv:
        ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        limit_ip = ev.raw_text.strip()

    await event.respond(box(" Quota (GB)", ["Masukkan Quota (GB):", "� 0 = Unlimited"], "Kirim angka."),
                        buttons=[[Button.inline(" Cancel", b"vless")]])
    async with bot.conversation(chat, timeout=120) as conv:
        ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        quota = ev.raw_text.strip()

    await event.respond(box(" Expired", ["Masukkan Expired (hari):"], "Kirim angka hari."),
                        buttons=[[Button.inline(" Cancel", b"vless")]])
    async with bot.conversation(chat, timeout=120) as conv:
        ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        days = ev.raw_text.strip()

    # progress mini
    for txt in ["Processing.", "Processing..", "Processing...", "Processing...."]:
        await event.respond(txt); time.sleep(0.4)
    await event.respond("`Processing Create Premium Account`"); time.sleep(0.6)
    bars = [
        ("0%",  "" * 22),
        ("4%",  "" + "" * 21),
        ("8%",  "" + "" * 20),
        ("20%", "" + "" * 17),
        ("36%", "" + "" * 13),
        ("52%", "" + "" * 9),
        ("84%", "" + "" * 2),
        ("100%","")
    ]
    for pct, bar in bars:
        await event.respond(f"`Processing... {pct}\n{bar} `")
        time.sleep(0.5)
    await event.respond("`Wait.. Setting up an Account`"); time.sleep(0.8)

    try:
        # Banyak skrip m-vless create: 1 username limit quota days
        vless_call(MENU_CREATE, username, limit_ip, quota, days)
    except Exception as e:
        msg = getattr(e,"output",b"").decode("utf-8","ignore") or str(e)
        return await event.respond(box(" Gagal Create", [msg], None), buttons=vless_menu_buttons())

    human_quota = "Unlimited" if quota == "0" else f"{quota} GB"
    await event.respond(
        box(" Berhasil",
            [f"User: {username}",
             f"Limit IP: {limit_ip}",
             f"Quota: {human_quota}",
             f"Expired: {days} hari"],
            "Pilih menu lain."),
        buttons=vless_menu_buttons()
    )

# ===================== TRIAL (dengan progress) =====================
@bot.on(events.CallbackQuery(data=b'vls-trial'))
async def vls_trial(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Akses Ditolak", alert=True)

    chat = event.chat_id
    await event.edit(box(" TRIAL VLESS", ["Ketik durasi trial (menit):"], "Kirim angka menit."),
                     buttons=[[Button.inline(" Cancel", b"vless")]])
    async with bot.conversation(chat, timeout=120) as conv:
        ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        minutes = ev.raw_text.strip()

    for txt in ["Processing.", "Processing..", "Processing...", "Processing...."]:
        await event.respond(txt); time.sleep(0.4)
    await event.respond("`Processing Trial Account`"); time.sleep(0.6)
    for pct, bar in [("0%",""*22),("50%",""+""*12),("100%","")]:
        await event.respond(f"`Processing... {pct}\n{bar} `"); time.sleep(0.6)

    try:
        vless_call(MENU_TRIAL, minutes)
    except Exception as e:
        msg = getattr(e,"output",b"").decode("utf-8","ignore") or str(e)
        return await event.respond(box(" Gagal Trial", [msg], None), buttons=vless_menu_buttons())

    await event.respond(box(" Berhasil", [f"Trial dibuat: {minutes} menit."], "Pilih menu lain."),
                        buttons=vless_menu_buttons())

# ===================== ONLINE (USER LOGIN) =====================
@bot.on(events.CallbackQuery(data=b'vls-online'))
async def vls_online(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Access Denied", alert=True)
    out = _sh("bot-cek-vless", "") or _sh("bot-cek-ws", "")
    await event.edit(box(" VLESS USER ONLINE", [out if out else "(Tidak ada user online)"]),
                     buttons=vless_menu_buttons())

# ===================== DETAIL (daftar user  submenu) =====================
@bot.on(events.CallbackQuery(data=b'vls-detail'))
async def vls_detail(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Akses Ditolak", alert=True)
    items = vls_users_active()
    msg   = box(" DETAIL VLESS", ["Pilih user untuk opsi Edit / Delete / Lock / Unlock:",
                                    "" if items else "(Tidak ada user)"], "Tap user.")
    btns, _ = paginate_buttons(items, "detail", page=1, cancel_cb=b"vless")
    await event.edit(msg, buttons=btns)

def detail_user_buttons(idx):
    return [
        [Button.inline(" Edit",   f"vls:edit:{idx}".encode()),
         Button.inline(" Delete", f"vls:del:{idx}".encode())],
        [Button.inline(" Lock IP",    f"vls:lockip:{idx}".encode()),
         Button.inline(" Unlock IP",  f"vls:unlockip:{idx}".encode())],
        [Button.inline(" Quota",  f"vls:equota:{idx}".encode()),
         Button.inline(" Cek Config", f"vls:cekcfg:{idx}".encode())],
        [Button.inline(" Back", b"vls-detail")]
    ]

def edit_menu_buttons(idx):
    return [
        [Button.inline(" Limit IP", f"vls:elimit:{idx}".encode()),
         Button.inline(" Renew",    f"vls:erenew:{idx}".encode())],
        [Button.inline(" Quota GB", f"vls:equota:{idx}".encode())],
        [Button.inline(" Back",     f"vls:detail:{idx}".encode())]
    ]

# ===================== ROUTER DINAMIS (vls:*) =====================
@bot.on(events.CallbackQuery())
async def vls_router(event):
    data = event.data or b""
    if not data.startswith(b"vls:"):
        return
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Akses Ditolak", alert=True)

    parts = data.decode().split(":")

    # Paging
    if len(parts) == 4 and parts[1] == "page":
        action, page = parts[2], int(parts[3])
        if action == "detail":
            items = vls_users_active()
            msg   = box(" DETAIL VLESS", ["Pilih user:"], "Tap user.")
            btns, _ = paginate_buttons(items, "detail", page, cancel_cb=b"vless")
            return await event.edit(msg, buttons=btns)

    # Detail user  submenu
    if len(parts) == 3 and parts[1] == "detail":
        idx = parts[2]
        try:
            raw = vless_call(MENU_CEKCFG, idx)
        except Exception:
            raw = ""
        msg  = box(" USER DETAIL", [(_strip_ansi(raw)[:1200] or f"User #{idx}")], "Pilih aksi:")
        return await event.edit(msg, buttons=detail_user_buttons(idx))

    # Delete
    if len(parts) == 3 and parts[1] == "del":
        idx = parts[2]
        try:
            vless_call(MENU_DELETE, idx)
        except Exception as e:
            msg = getattr(e,"output",b"").decode("utf-8","ignore") or str(e)
            return await event.edit(box(" Gagal Hapus", [msg], None), buttons=vless_menu_buttons())
        return await event.edit(box(" Dihapus", [f"User #{idx} dihapus."], "Selesai."), buttons=vless_menu_buttons())

    # Edit submenu
    if len(parts) == 3 and parts[1] == "edit":
        idx = parts[2]
        return await event.edit(box(f" EDIT User #{idx}", ["Pilih item yang mau diubah:"], "Limit � Renew � Quota"),
                                buttons=edit_menu_buttons(idx))

    # Limit IP (menu 7) � kalau skripmu butuh quota juga, kita minta kuota setelah pilih IP
    if len(parts) == 3 and parts[1] == "elimit":
        idx = parts[2]
        rows, row = [], []
        for i, v in enumerate(LIMIT_IP_CHOICES, 1):
            row.append(Button.inline(v, f"vls:limitip:{idx}:{v}".encode()))
            if i % 3 == 0: rows.append(row); row=[]
        if row: rows.append(row)
        rows.append([Button.inline(" Back", f"vls:edit:{idx}".encode())])
        return await event.edit(box(f" Limit IP User #{idx}", ["Pilih nilai Limit IP:"]), buttons=rows)

    if len(parts) == 4 and parts[1] == "limitip":
        idx, ip = parts[2], parts[3]
        # Tanyakan quota juga agar kompatibel dengan skrip MENU_SET_LIMIPQ (7) yg menerima ip & quota sekaligus
        rows, row = [], []
        for i, q in enumerate(QUOTA_CHOICES, 1):
            row.append(Button.inline(q, f"vls:limitset:{idx}:{ip}:{q}".encode()))
            if i % 3 == 0: rows.append(row); row=[]
        if row: rows.append(row)
        rows.append([Button.inline(" Back", f"vls:elimit:{idx}".encode())])
        return await event.edit(box(f" Quota User #{idx}", [f"Limit IP dipilih: {ip}", "Pilih Quota (GB):"]), buttons=rows)

    if len(parts) == 5 and parts[1] == "limitset":
        idx, ip, quota = parts[2], parts[3], parts[4]
        try:
            vless_call(MENU_SET_LIMIPQ, idx, ip, quota)
        except Exception as e:
            msg = getattr(e,"output",b"").decode("utf-8","ignore") or str(e)
            return await event.edit(box(" Gagal Update", [msg], None), buttons=vless_menu_buttons())
        human = "Unlimited" if quota == "0" else f"{quota} GB"
        return await event.edit(box(" Limit/Quota Update", [f"User #{idx}  IP {ip}, Quota {human}."], "Selesai."),
                                buttons=vless_menu_buttons())

    # Renew expired
    if len(parts) == 3 and parts[1] == "erenew":
        idx = parts[2]
        rows, row = [], []
        for i, d in enumerate(RENEW_CHOICES, 1):
            row.append(Button.inline(d, f"vls:renewset:{idx}:{d}".encode()))
            if i % 3 == 0: rows.append(row); row=[]
        if row: rows.append(row)
        rows.append([Button.inline(" Back", f"vls:edit:{idx}".encode())])
        return await event.edit(box(f" Renew User #{idx}", ["Pilih durasi (hari):"]), buttons=rows)

    if len(parts) == 4 and parts[1] == "renewset":
        idx, days = parts[2], parts[3]
        try:
            vless_call(MENU_RENEW_EXP, idx, days)
        except Exception as e:
            msg = getattr(e,"output",b"").decode("utf-8","ignore") or str(e)
            return await event.edit(box(" Gagal Renew", [msg], None), buttons=vless_menu_buttons())
        return await event.edit(box(" Renew Berhasil", [f"User #{idx} diperpanjang {days} hari."], "Selesai."),
                                buttons=vless_menu_buttons())

    # Quota saja (menu 10)
    if len(parts) == 3 and parts[1] == "equota":
        idx = parts[2]
        rows, row = [], []
        for i, q in enumerate(QUOTA_CHOICES, 1):
            row.append(Button.inline(q, f"vls:quotaset:{idx}:{q}".encode()))
            if i % 3 == 0: rows.append(row); row=[]
        if row: rows.append(row)
        rows.append([Button.inline(" Custom", f"vls:quotaask:{idx}".encode())])
        rows.append([Button.inline(" Back", f"vls:edit:{idx}".encode())])
        return await event.edit(box(f" Quota User #{idx}", ["Pilih Kuota (GB):", "0 = Unlimited"]), buttons=rows)

    if len(parts) == 4 and parts[1] == "quotaset":
        idx, gb = parts[2], parts[3]
        try:
            vless_call(MENU_SET_QUOTA, idx, gb)
        except Exception as e:
            msg = getattr(e,"output",b"").decode("utf-8","ignore") or str(e)
            return await event.edit(box(" Gagal Set Kuota", [msg], None), buttons=vless_menu_buttons())
        human = "Unlimited" if gb == "0" else f"{gb} GB"
        return await event.edit(box(" Kuota Diset", [f"User #{idx}  {human}."], "Selesai."),
                                buttons=vless_menu_buttons())

    if len(parts) == 3 and parts[1] == "quotaask":
        idx   = parts[2]
        chat  = event.chat_id
        await event.edit(box(" KUOTA CUSTOM", ["Ketik angka kuota (GB):", "� 0 = Unlimited"], "Kirim angkanya."),
                         buttons=[[Button.inline(" Back", f"vls:equota:{idx}".encode())]])
        async with bot.conversation(chat, timeout=120) as conv:
            ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=(await event.get_sender()).id))
            gb = ev.raw_text.strip()
        try:
            vless_call(MENU_SET_QUOTA, idx, gb)
        except Exception as e:
            msg = getattr(e,"output",b"").decode("utf-8","ignore") or str(e)
            return await event.respond(box(" Gagal Set Kuota", [msg], None), buttons=vless_menu_buttons())
        human = "Unlimited" if gb == "0" else f"{gb} GB"
        return await event.respond(box(" Kuota Diset", [f"User #{idx}  {human}."], "Selesai."),
                                   buttons=vless_menu_buttons())

    # Lock / Unlock IP
    if len(parts) == 3 and parts[1] == "lockip":
        idx = parts[2]
        try:
            # Jika skripmu punya menu khusus lock IP, ganti di sini. Fallback: set limit 0 via menu 7.
            vless_call(MENU_SET_LIMIPQ, idx, "0", "0")
        except Exception as e:
            msg = getattr(e,"output",b"").decode("utf-8","ignore") or str(e)
            return await event.edit(box(" Gagal Lock", [msg], None), buttons=vless_menu_buttons())
        return await event.edit(box(" Locked", [f"User #{idx} dikunci (IP)."], None), buttons=vless_menu_buttons())

    if len(parts) == 3 and parts[1] == "unlockip":
        idx = parts[2]
        try:
            vless_call(MENU_UNLOCK_IP, idx)
        except Exception as e:
            msg = getattr(e,"output",b"").decode("utf-8","ignore") or str(e)
            return await event.edit(box(" Gagal Unlock", [msg], None), buttons=vless_menu_buttons())
        return await event.edit(box(" Unlocked", [f"User #{idx} dibuka (IP)."], None), buttons=vless_menu_buttons())

    # Cek Config
    if len(parts) == 3 and parts[1] == "cekcfg":
        idx = parts[2]
        raw = vless_call(MENU_CEKCFG, idx)
        return await event.edit(render_cfg_mono(raw), buttons=vless_menu_buttons())

    return
Button.inline(" Limit ","limit7-vless")],
[Button.inline(" Renew","renew7-vless"),
Button.inline(" Restore ","restore7-vless"),
Button.inline(" Akun ","akun7-vless")],
[Button.inline("‹ BACK ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		vl = f' cat /etc/xray/config.json | grep "#vlg" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		msg = f"""
**✧◇───────────────────◇✧** 
**🔥 𝙿𝙰𝙽𝙴𝙻 𝙼𝙴𝙽𝚄 𝚅𝙻𝙴𝚂𝚂 🔥**
**✧◇───────────────────◇✧** 
✨ **» Service:** `VLESS`
✨ **» Total Account  :** `{vls.strip()}` __account__
✨ **» Host:** `{DOMAIN}`
✨ **» ISP:** `{z["isp"]}`
✨ **» Country:** `{z["country"]}`
🤖 **» Bot by @AcilOffcial**
**✧◇───────────────────◇✧** 
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vless_(event)
	else:
		await event.answer("Access Denied",alert=True)
